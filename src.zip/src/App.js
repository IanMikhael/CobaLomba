import React, { useEffect } from "react";
import Navbar from "./Components/Navbar/Navbar";
import Hero from "./Components/Hero/Hero";
import BackgroundEffect from "./Components/UI/BackgroundEffect";
import Testimonial from "./Components/Testimonial/Testimonial";
import MengapaKami from "./Components/WhyUs/MengapaKami";
import Blogs from "./Components/Blogs/Blogs";
import MenuKami from "./Components/MenuKami/MenuKami";
import Reservasi from "./Components/Reservasi/Reservasi";
import Footer from "./Components/Footer/Footer";
import ScrollToTop from "./Components/UI/ScrollToTop";
import AOS from "aos";
import "aos/dist/aos.css";

function App() {
  useEffect(() => {
    AOS.init({ once: true });
  }, []);

  return (
    <div className="relative flex flex-col gap-16 bg-transparent scroll-smooth">
      <ScrollToTop />
      <section className="relative w-full h-20 xl:h-32 ">
        <Navbar />
      </section>
      <BackgroundEffect />
      <Hero />
      <MengapaKami />
      <MenuKami />
      <Blogs />
      <Testimonial />
      <Reservasi />
      <Footer />
    </div>
  );
}

export default App;
