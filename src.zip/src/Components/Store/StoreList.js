import React, { useEffect, useState } from "react";
import StoreCard from "./StoreCard";
// import CartCard from "./CartCard";
import Search from "../Icons/Search";

import { dataMenu as dataMenus } from "../../Data";

export default function StoreList(props) {
  const { updateData, updatePrice } = props;
  const [filterKey, setFilterKey] = useState("Semua Menu");

  const [searchKey, setSearchKey] = useState("");

  const updateHandler = (data) => {
    setFilterKey(data.target.value);
  };

  const dataButton = [
    {
      title: "Semua Menu",
    },
    {
      title: "Favorite",
    },
    {
      title: "Terbaru",
    },
    {
      title: "Terlaris",
    },
    {
      title: "Minuman",
    },
    {
      title: "Selain Mi",
    },
  ];

  const [dataMenu, setDataMenu] = useState(dataMenus);

  const [dataKeranjang, setDataKeranjang] = useState([]);

  const insertCart = (data) => {
    if (data.q > 0) {
      setDataKeranjang((prevDataKeranjang) => {
        const existingItem = prevDataKeranjang.find(
          (item) => item.name === data.name
        );
        if (!existingItem) {
          // if item not found, add new item
          return [...prevDataKeranjang, data];
        } else {
          // if item found, update the quantity
          const updatedDataKeranjang = prevDataKeranjang.map((item) => {
            if (item.name === data.name) {
              return { ...item, q: data.q };
            } else {
              return item;
            }
          });
          return updatedDataKeranjang;
        }
      });

      setDataMenu((prevDataMenu) => {
        const updatedDataMenu = prevDataMenu.map((item) => {
          if (item.name === data.name) {
            return { ...item, q: data.q };
          } else {
            return item;
          }
        });
        return updatedDataMenu;
      });
    } else {
      // remove item if quantity is 0
      setDataKeranjang((prevDataKeranjang) => {
        const updatedDataKeranjang = prevDataKeranjang.filter(
          (item) => item.name !== data.name
        );
        return updatedDataKeranjang.length === 0 ? [] : updatedDataKeranjang;
      });

      setDataMenu((prevDataMenu) => {
        const updatedDataMenu = prevDataMenu.map((item) => {
          if (item.name === data.name) {
            return { ...item, q: data.q };
          } else {
            return item;
          }
        });
        return updatedDataMenu;
      });
    }
  };

  const totalPrice = dataKeranjang.reduce((total, item) => {
    return total + item.price * item.q;
  }, 0);

  const searchHandler = (data) => {
    setSearchKey(data.target.value);
    // setTimeout(() => {
    // }, 300);
    console.log(searchKey);
  };

  const filterFunction = () =>
    dataMenu
      .filter((e) =>
        filterKey === "Semua Menu" ? e : e.cat.includes(filterKey)
      )
      .filter((e) =>
        searchKey === ""
          ? e
          : e.name.toLowerCase().includes(searchKey.toLowerCase())
      );

  const errorMessage = () => (
    <div className="w-full py-4 mx-2 bg-white rounded-lg flex-center">
      <p className="flex-col font-bold text-text-gray text-size-title flex-center">
        Ouchh! Menu tidak ditemukan :(
        <span className="font-normal text-size-content text-text-gray">
          Coba telusuri dengan kata kunci lainnya...
        </span>
      </p>
    </div>
  );

  useEffect(() => {
    updateData(dataKeranjang);
    updatePrice(totalPrice);
  }, [dataKeranjang, updateData, updatePrice, totalPrice]);

  return (
    <div className="flex flex-col gap-4 containers">
      {/* Search form */}
      <div className="flex items-center gap-4 bg-white rounded-lg padding-btn">
        <Search />
        <input
          className="w-full outline-none text-size-content"
          placeholder="Temukan menu anda disini..."
          onChange={searchHandler}
        />
      </div>

      {/* Category Button */}
      <div className="flex justify-start gap-2 overflow-x-auto sm:gap-4 sm:mb-8">
        {dataButton.map((e, index) => {
          if (e.title === filterKey)
            return (
              <button
                className="red-btn"
                value={e.title}
                onClick={updateHandler}
                key={index}
              >
                {e.title}
              </button>
            );
          else
            return (
              <button
                className="red-hover-btn "
                value={e.title}
                onClick={updateHandler}
                key={index}
              >
                {e.title}
              </button>
            );
        })}
      </div>

      <div className="flex">
        {/* Menu Section */}
        <div className={`flex-menu w-[105%] -mx-2`}>
          {/* Filtering function */}
          {filterFunction().map((e, index) => (
            <StoreCard {...e} key={index} insertCartHandler={insertCart} />
          ))}
          {filterFunction().length === 0 ? errorMessage() : null}
        </div>
      </div>
    </div>
  );
}
