import React, { useEffect, useState, Fragment } from "react";

export default function StoreCard({ insertCartHandler, ...props }) {
  const [quantity, setQuantity] = useState(props.q);
  const [isShow, setIsShow] = useState(false);

  const rupiah = (number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
    }).format(number);
  };

  useEffect(() => {
    insertCartHandler({ ...props, q: quantity });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [quantity]);

  return (
    <div className="w-1/2 px-2 md:w-1/3 lg:w-1/4">
      <div className="w-full h-full p-4 bg-white rounded-lg">
        <div className="flex flex-col justify-between h-full gap-4">
          <div>
            <img
              src={props.src}
              alt={props.name}
              className="object-contain w-2/3 mx-auto xl:w-4/5 aspect-square"
            />
            <div className="flex flex-col gap-2 ">
              <div>
                <p className="font-bold text-center text-size-title">
                  {props.name}
                </p>
                <p
                  className={`overflow-y-hidden text-center text-text-gray cursor-pointer text-size-content ${
                    isShow ? "line-clamp-none" : "line-clamp-3 "
                  }`}
                  onClick={() => setIsShow(!isShow)}
                >
                  {props.desc}
                </p>
              </div>
            </div>
          </div>
          <div className="flex flex-col justify-between sm:items-center sm:flex-row md:flex-col xl:flex-row gap-y-2 sm:gap-y-0 md:gap-y-2 xl:gap-y-0">
            <p className="font-bold text-center text-red-logo text-size-content">
              {rupiah(props.price)}
            </p>
            <div className="flex items-center justify-end w-full gap-4 xl:gap-2">
              {/* {console.log(props.q, "FROM HERE", props.name)} */}
              {props.q > 0 ? (
                <Fragment>
                  <p
                    className="red-outline-circle-btn"
                    onClick={() =>
                      quantity > 0 ? setQuantity(quantity - 1) : null
                    }
                  >
                    -
                  </p>
                  <p className="text-red-logo text-size-content">{props.q}</p>
                </Fragment>
              ) : null}

              <p
                className="red-outline-circle-btn"
                onClick={() => setQuantity(quantity + 1)}
              >
                +
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
