import React from "react";

export default function CartCard({ insertCartHandler, ...props }) {
  const rupiah = (number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
    }).format(number);
  };

  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-4">
        <img
          src={props.src}
          className="object-contain w-16 aspect-square"
          alt={props.name}
        />
        <div className="flex flex-col">
          <p className="font-bold">{props.name}</p>
          <p className="text-text-gray">
            {rupiah(props.price)} x {props.q}
          </p>
        </div>
      </div>
    </div>
  );
}
