import React, { useRef, useEffect } from "react";
import CartCard from "./CartCard";
import { useNavigate } from "react-router-dom";

export default function PopupCart({ data, cartOnClick, totalPrice }) {
  const navigate = useNavigate();

  const popupRef = useRef(null);

  useEffect(() => {
    const handleOutsideClick = (event) => {
      if (popupRef.current && !popupRef.current.contains(event.target)) {
        // Clicked outside the popup, close the cart
        cartOnClick(false);
      }
    };

    // Attach the event listener when the component mounts
    document.addEventListener("mousedown", handleOutsideClick);

    // Clean up the event listener when the component unmounts
    return () => {
      document.removeEventListener("mousedown", handleOutsideClick);
    };
  }, [cartOnClick]);

  const rupiah = (number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
    }).format(number);
  };

  const handlePayment = () => {
    const dataSend = {
      ...data,
      totalPrice,
    };
    const dataString = encodeURIComponent(JSON.stringify(dataSend));
    navigate(`/store/payment?data=${dataString}`);
  };

  return (
    <div className="fixed inset-0 bg-black flex-center bg-opacity-70 containers">
      <div
        className="flex-col w-full p-4 bg-white rounded-lg lg:w-1/3 xl:w-1/3 h-max lg:flex"
        ref={popupRef}
      >
        <p className="flex justify-between pb-2 mb-2 text-xl font-bold border-b-2">
          Keranjang{" "}
          <span className="text-red-logo">
            {!data.length ? null : data.length}
          </span>
        </p>
        {/* Check if data is empty */}
        {!data.length ? (
          <p className="text-text-gray">Keranjangmu masih kosong...</p>
        ) : (
          // If data available then map the data and render it
          // CHECKPOINTTTTTTT
          <div className="flex flex-col gap-2">
            <div className="pr-4 overflow-auto max-h-96">
              {data.map((e, index) => {
                return <CartCard key={index} {...e} />;
              })}
            </div>
            <div className="flex items-center justify-between pt-2 mt-2 border-t-2">
              <p className="font-bold">Total</p>
              <p className="font-bold">{rupiah(totalPrice)}</p>
            </div>
            <button
              className="w-full mt-4 red-outline-btn"
              onClick={handlePayment}
            >
              Buat Pesanan
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
