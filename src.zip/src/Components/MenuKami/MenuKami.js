import { useState, useEffect } from "react";
import MenuCard from "./MenuCard";

// Importing AOS library
import AOS from "aos";
import "aos/dist/aos.css";

const { dataButton, dataMenu } = require("../../Data");

export default function MenuKami() {
  // Initialize AOS library using useEffect with [] dependency
  useEffect(() => {
    AOS.init({ once: true });
  }, []);

  const [filterKey, setFilterKey] = useState("Menu Favorite");

  const updateHandler = (data) => {
    setFilterKey(data.target.value);
  };

  return (
    <div className="flex flex-col gap-4 px-4 sm:px-6 lg:px-8 xl:px-16">
      <p className="font-bold text-center text-size-header" data-aos="fade-up">
        Menu Kami
      </p>

      {/* Render button with filter key */}
      <div
        className="flex justify-center gap-4 sm:mb-24"
        data-aos="fade-right"
        data-aos-delay="100"
      >
        {dataButton.map((e, index) => {
          if (e.title === filterKey)
            return (
              <button
                className=" red-btn"
                value={e.title}
                onClick={updateHandler}
                key={index}
              >
                {e.title}
              </button>
            );
          else
            return (
              <button
                className="flex-shrink red-btn red-hover-btn"
                value={e.title}
                onClick={updateHandler}
                key={index}
              >
                {e.title}
              </button>
            );
        })}
      </div>

      {/* Render menu items */}
      <div
        className={`grid gap-4 grid-cols-sm md:grid-cols-menu-lg xl:grid-cols-menu-xl`}
      >
        {dataMenu
          .filter((e, index) => e.cat === filterKey && index < 12)
          .map((e, index) => {
            return <MenuCard {...e} key={index} />;
          })}
      </div>
    </div>
  );
}
