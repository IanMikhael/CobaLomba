import { useEffect, useState } from "react";

// Importing AOS library
import AOS from "aos";
import "aos/dist/aos.css";

export default function MenuCard(props) {
  // Initialize AOS library using useEffect with [] dependency
  useEffect(() => {
    AOS.init({ once: true });
  }, []);

  const [isShow, setIsShow] = useState(false);

  return (
    <div
      className="box-border relative flex flex-col items-center w-full p-4 pb-6 bg-white rounded-2xl sm:mb-16 xl:mb-0"
      data-aos="fade-right"
    >
      <img
        src={props.src}
        className="relative object-contain w-64 h-64 sm:-top-24"
        alt={props.name}
      />
      <p className="font-bold text-size-title sm:-mt-24">{props.name}</p>
      <p
        className={`text-center text-text-gray text-size-content cursor-pointer ${
          isShow ? "line-clamp-none" : "line-clamp-3"
        }`}
        onClick={() => setIsShow(!isShow)}
      >
        {props.desc}
      </p>
    </div>
  );
}
