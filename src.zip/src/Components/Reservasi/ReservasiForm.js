import React, { useState } from "react";
import InputDropDown from "../UI/InputDropDown";
import InputText from "../UI/InputText";
import InputDate from "../UI/InputDate";

export default function ReservasiForm(props) {
  const [formValues, setFormValues] = useState({
    nama: "",
    email: "",
    wa: "",
  });
  const [formErrors, setFormErrors] = useState({
    nama: "",
    email: "",
    wa: "",
  });

  const dataDropDown = {
    title: "Jumlah Tamu",
    id: "jumlah",
    default: "--- Pilih jumlah tamu ---",
    data: ["1 - 4 Orang", "5 - 8 Orang", "9 - 12 Orang", "Lebih dari 13 Orang"],
  };

  const dataDate = {
    title: "Tanggal dan Jam",
    id: "waktu",
  };

  const dataInput = [
    {
      title: "Nama Lengkap",
      id: "nama",
      placeholder: "Nama Lengkap",
      type: "text",
    },
    {
      title: "Email",
      id: "email",
      placeholder: "Alamat Email",
      type: "text",
    },
    {
      title: "No. Whatsapp",
      id: "wa",
      placeholder: "No. Whatsapp aktif",
      type: "tel",
    },
  ];

  const validateForm = () => {
    let isValid = true;
    const errors = {};

    // Validate Nama Lengkap
    if (formValues.nama.trim() === "") {
      isValid = false;
      errors.nama = "Nama Lengkap harus diisi";
    }

    // Validate Email
    if (formValues.email.trim() === "") {
      isValid = false;
      errors.email = "Email harus diisi";
    } else if (!/^\S+@\S+\.\S+$/.test(formValues.email.trim())) {
      isValid = false;
      errors.email = "Email tidak valid";
    }

    // Validate No. Whatsapp
    if (formValues.wa.trim() === "") {
      isValid = false;
      errors.wa = "No. Whatsapp harus diisi";
    } else if (!/^\d+$/.test(formValues.wa.trim())) {
      isValid = false;
      errors.wa = "No. Whatsapp harus berupa angka";
    }

    // Validate InputDate
    if (!formValues.waktu) {
      isValid = false;
      errors.waktu = "Tanggal dan Jam harus dipilih";
    }

    // Validate InputDropDown
    if (formValues.jumlah === "--- Pilih jumlah tamu ---") {
      isValid = false;
      errors.jumlah = "Jumlah Tamu harus dipilih";
    }

    setFormErrors(errors);
    return isValid;
  };

  const changeHandler = (id, value) => {
    setFormValues((prevValues) => ({
      ...prevValues,
      [id]: value,
    }));
  };

  const submitHandler = (event) => {
    event.preventDefault();

    if (validateForm()) {
      // Form is valid, perform submission or other actions
      console.log("Form submitted:", formValues);
      // Reset form values
      setFormValues({
        nama: "",
        email: "",
        wa: "",
        waktu: "", // Add inputDate to formValues
        jumlah: "", // Add inputDropDown to formValues
      });
      setFormErrors({
        nama: "",
        email: "",
        wa: "",
      });
      // Show success alert or perform other actions
      props.showAlertHandler(true);
    } else {
      // Form is not valid, handle error or display error messages
      console.log("Form validation failed");
    }
  };

  return (
    <div className="flex flex-col gap-4 px-4 py-4 bg-white rounded-lg lg:px-8">
      <p className="font-bold text-center text-size-header text-red-logo">
        Reservasi
      </p>
      <form
        method="POST"
        className="flex flex-col gap-4"
        onSubmit={submitHandler}
      >
        <div className="flex flex-col gap-4 lg:flex-row">
          <InputDropDown
            {...dataDropDown}
            value={formValues.jumlah}
            onChange={changeHandler}
          />
          <InputDate
            {...dataDate}
            value={formValues[dataDate.id]}
            error={formErrors[dataDate.id]}
            onChange={changeHandler}
          />
        </div>
        <div className="flex flex-col gap-4">
          {dataInput.map((input, index) => (
            <InputText
              {...input}
              key={index}
              value={formValues[input.id]}
              error={formErrors[input.id]}
              onChange={changeHandler}
            />
          ))}
        </div>
        <div className="flex justify-end gap-4">
          <button type="reset" className="red-outline-btn">
            Reset
          </button>
          <button type="submit" className="red-btn">
            Reservasi
          </button>
        </div>
      </form>
    </div>
  );
}
