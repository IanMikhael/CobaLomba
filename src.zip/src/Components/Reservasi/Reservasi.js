import React from "react";
import HeroImage from "../../Assets/Menu_Compressed/MiDaunJeruk.png";
import { Link } from "react-router-dom";

export default function Reservasi() {
  return (
    <div className="mx-4 sm:mx-6 lg:mx-8 xl:mx-16 bg-reserve rounded-[32px] flex items-center xl:px-32 md:px-16 flex-col md:flex-row md:gap-8 xl:gap-32 xl:justify-between py-4">
      <img src={HeroImage} alt="Reservation" className="w-1/2 md:w-1/3" />
      <div className="flex flex-col w-full gap-4 px-4 md:w-2/3 md:gap-8 md:px-0">
        <p className="text-2xl font-bold text-center md:text-3xl xl:text-4xl md:text-left ">
          Ingin Buat Acara Bersama Keluarga atau Teman? Reservasi Tempatmu
          Sekarang!
        </p>
        <Link to="/reserve" className="mx-auto md:mx-0">
          <button className="red-btn-xl padding-btn w-max">Reservasi</button>
        </Link>
      </div>
    </div>
  );
}
