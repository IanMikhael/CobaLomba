import React from "react";
import Background from "../../Assets/Background.png";

export default function BackgroundEffect() {
  return (
    <div>
      <img
        src={Background}
        className="absolute w-full h-full -mt-48 -z-50 bg-primary"
        alt="Background effect"
      />
    </div>
  );
}
