import React from "react";

export default function InputDate(props) {
  const handleChange = (event) => {
    const { value } = event.target;
    props.onChange(props.id, value);
  };

  return (
    <div className="flex flex-col w-full gap-2">
      <label
        className={` text-size-content ${
          props.error ? "text-red-logo" : "text-text-gray"
        }`}
        htmlFor={props.id}
      >
        {props.title}
      </label>
      <input
        type="datetime-local"
        className={`outline-input ${props.error ? "border-red-logo" : ""}`}
        id={props.id}
        value={props.value || ""}
        onChange={handleChange}
      />
      {props.error && (
        <p className="text-red-logo text-size-content">{props.error}</p>
      )}
    </div>
  );
}
