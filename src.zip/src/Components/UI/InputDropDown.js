import React from "react";

export default function InputDropDown(props) {
  const handleChange = (event) => {
    const { value } = event.target;
    props.onChange(props.id, value);
  };

  return (
    <div className="flex flex-col w-full gap-2">
      <label className="text-text-gray text-size-content" htmlFor={props.id}>
        {props.title}
      </label>
      <select
        className="outline-input"
        id={props.id}
        value={props.value}
        onChange={handleChange}
      >
        <option value="" disabled>
          {props.default}
        </option>
        {props.data.map((option, index) => (
          <option key={index} value={option}>
            {option}
          </option>
        ))}
      </select>
    </div>
  );
}
