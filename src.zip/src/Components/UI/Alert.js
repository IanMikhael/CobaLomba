import React, { useEffect, useRef, useState } from "react";

export default function Alert({ onClose, message }) {
  const alertRef = useRef();
  const [countdown, setCountdown] = useState(600);

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prevCountdown) => prevCountdown - 1);
    }, 1000);

    const handleClickOutside = (event) => {
      if (alertRef.current && !alertRef.current.contains(event.target)) {
        onClose();
      }
    };

    document.addEventListener("mousedown", handleClickOutside);

    return () => {
      clearInterval(timer);
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [onClose]);

  const formatTime = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, "0")}:${remainingSeconds
      .toString()
      .padStart(2, "0")}`;
  };

  const copyText = () => {
    const input = document.getElementById("titleInput");
    input.select();
    document.execCommand("copy");
  };
  return (
    <div className="fixed inset-0 bg-black flex-center bg-opacity-70 containers ">
      <div
        ref={alertRef}
        className="flex-col gap-8 p-4 bg-white rounded-lg flex-center lg:max-w-xl"
      >
        <img
          src={
            message.barcode ? message.barcode : "https://i.gifer.com/7efs.gif"
          }
          alt="Success Alert"
          className={message.barcode ? "w-1/2" : ""}
        />

        <span
          className={`text-center ${
            message.barcode ? "-mt-8 sm:-mt-12" : "-mt-16"
          }`}
        >
          {message.barcode ? (
            <span className="flex items-center justify-center">
              <input
                type="text"
                id="titleInput"
                value={message.title}
                readOnly
                className="w-40 font-bold text-center outline-none text-size-title"
              />
              <button onClick={copyText}>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="w-5 h-5"
                  viewBox="0 0 20 20"
                  fill="currentColor"
                >
                  <path
                    fillRule="evenodd"
                    d="M13 2a3 3 0 013 3v5a3 3 0 01-3 3H7a3 3 0 01-3-3V5a3 3 0 013-3h6zm-1 3H7a1 1 0 00-1 1v5a1 1 0 001 1h5a1 1 0 001-1V6a1 1 0 00-1-1zM6 15a1 1 0 100 2h8a1 1 0 100-2H6z"
                    clipRule="evenodd"
                  />
                </svg>
              </button>
            </span>
          ) : (
            <p className="font-bold text-size-title">{message.title}</p>
          )}
          {message.barcode && (
            <span className="flex items-center justify-center mt-4">
              <p className="font-bold text-red-logo text-size-content">
                Waktu Tersisa: {formatTime(countdown)}
              </p>
            </span>
          )}
          <p className="text-size-content">{message.content}</p>
        </span>
        <p className="pb-8 text-center text-size-content text-text-gray">
          {message.additional.text}{" "}
          <span className="underline">{message.additional.link}</span>
        </p>
      </div>
    </div>
  );
}
