import React from "react";
import Star from "../Icons/Star";

export default function TestimonialCard(props) {
  return (
    <div className="flex flex-col justify-center h-full gap-2 bg-transparent lg:px-16">
      <div className="flex items-center gap-4">
        <img
          src={props.src}
          className="object-cover w-16 h-16 rounded-full"
          alt={props.name}
        />
        <div className="flex flex-col ">
          <p className="font-bold text-size-title">{props.name}</p>
          <p className="text-text-gray text-size-content">{props.date}</p>
        </div>
      </div>
      <p className="text-size-content">
        <q> {props.desc} </q>
      </p>
      <div className="flex items-center gap-2">
        <div className="flex">
          {Array.from({ length: props.star }).map((_, index) => (
            <Star color="#ffe234" key={index} />
          ))}
        </div>
        <p className="text-size-content text-text-gray">{props.star}.0</p>
      </div>
    </div>
  );
}
