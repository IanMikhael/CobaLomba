import { useEffect } from "react";
// import TestimonialSlide from "./TestimonialSlide";
import TestimonialCard from "./TestimonialCard";
import TestimonialImage from "../../Assets/Testimonial-compress.png";

// Import Swiper React components
import { Swiper, SwiperSlide } from "swiper/react";

// Import Swiper styles
import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/navigation";

import { Autoplay, Pagination, Navigation } from "swiper";

// Importing AOS library
import AOS from "aos";
import "aos/dist/aos.css";

const { dataTestimonial } = require("../../Data");

export default function Testimonial() {
  // Initialize AOS library using useEffect with [] dependency
  useEffect(() => {
    AOS.init({ once: true });
  }, []);

  return (
    <div className="flex flex-col gap-4 containers">
      <p className="font-bold text-center text-size-header" data-aos="fade-up">
        Apa Kata Pelanggan Tentang MiTime?
      </p>
      <div className="flex flex-col gap-4 lg:flex-row">
        <img
          src={TestimonialImage}
          alt="Beautiful chef cooking noodles"
          className="w-3/4 h-auto mx-auto lg:w-1/2 xl:w-1/3"
          data-aos="fade-right"
          data-aos-delay="100"
        />
        {/* <TestimonialSlide /> */}

        <div className="w-full lg:w-1/2 xl:w-2/3" data-aos="fade-down">
          <Swiper
            spaceBetween={30}
            centeredSlides={true}
            autoplay={{
              delay: 6000,
              disableOnInteraction: false,
            }}
            loop={true}
            pagination={{
              clickable: true,
            }}
            navigation={true}
            modules={[Autoplay, Pagination, Navigation]}
            className="h-full"
            style={{
              "--swiper-navigation-color": "#B45054",
              "--swiper-pagination-color": "#B45054",
              "--swiper-navigation-size": "24px",
            }}
          >
            {dataTestimonial.map((e, index) => (
              <SwiperSlide className="px-16 pt-4 pb-8 lg:p-0" key={index}>
                <TestimonialCard {...e} />
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
      </div>
    </div>
  );
}
