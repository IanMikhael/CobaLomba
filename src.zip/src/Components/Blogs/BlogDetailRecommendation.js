import React from "react";
import { Link } from "react-router-dom";
const { dataBlogs } = require("../../Data");

export default function BlogDetailRecommendation() {
  return (
    <div className="flex flex-col gap-4 xl:px-80 containers">
      <span className="flex items-center justify-between">
        <p className="font-bold text-size-title text-red-logo ">
          Rekomendasi Untukmu
        </p>
        <Link to="/blogs">
          <p className="transition cursor-pointer text-size-content-sm text-text-gray hover:text-red-logo">
            Selengkapnya {">"}
          </p>
        </Link>
      </span>
      <div className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:gap-4 xl:gap-y-8">
        {dataBlogs.map((data, index) => (
          <div
            key={index}
            className="flex flex-col w-full gap-2 pb-2 transition rounded-lg cursor-pointer hover:text-red-logo"
          >
            <img
              src={data.src}
              className="rounded-lg aspect-video"
              alt={data.title}
            />
            <p className="font-bold text-size-title line-clamp-2">
              {data.title}
            </p>
            <p className="text-text-gray text-size-content line-clamp-2">
              {data.content || "Baca Selengkapnya disini"}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
