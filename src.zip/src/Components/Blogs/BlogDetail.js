import React from "react";
import Navbar from "../Navbar/Navbar";
import BlogDetailRecommendation from "./BlogDetailRecommendation";
import Footer from "../Footer/Footer";

const { dataBlogs } = require("../../Data");

export default function BlogDetail() {
  return (
    <div className="flex flex-col gap-4 bg-primary">
      <section className="relative w-full h-20">
        <Navbar />
      </section>
      <div className="flex flex-col gap-4 py-4 xl:px-80 containers">
        <span className="flex flex-col gap-1 text-center text-size-content-sm text-text-gray">
          <p>Diposting pada {dataBlogs[0].data}</p>
          <p>Oleh {dataBlogs[0].author}</p>
        </span>
        <p className="font-bold text-center text-size-header">
          {dataBlogs[0].title}
        </p>
        <span className="flex justify-center gap-2">
          {dataBlogs[0].tags.map((data, index) => (
            <p
              key={index}
              className="px-4 py-2 border border-text-gray rounded-3xl w-max text-size-content-sm"
            >
              {data}
            </p>
          ))}
        </span>
      </div>
      <div className="xl:px-64 containers">
        <img
          src={dataBlogs[0].src}
          className="object-cover w-full"
          alt={dataBlogs[0].title}
        />
        <p className="text-size-content-sm text-text-gray">Foto: Listverse</p>
      </div>
      <div className="flex flex-col gap-4 containers xl:px-80">
        {dataBlogs[0].content.map((data, index) => (
          <p
            key={index}
            className={`text-size-content ${index === 0 ? "font-bold" : ""}`}
          >
            {data}
          </p>
        ))}
      </div>
      <BlogDetailRecommendation />
      <Footer />
    </div>
  );
}
