import React from "react";
// import InputText from "../UI/InputText";
import Headline from "./Headline";

export default function BlogsPage() {
  return (
    <div className="flex flex-col gap-4 containers">
      {/* <div>
        <InputText type="text" placeholder="Cari..." />
      </div> */}
      <div>
        <Headline />
      </div>
    </div>
  );
}
