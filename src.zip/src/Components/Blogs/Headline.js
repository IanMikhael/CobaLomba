import React from "react";
import { Link } from "react-router-dom";

export default function Headline() {
  return (
    <div className="flex flex-col gap-4 xl:flex-row xl:items-center">
      <img
        src="https://akcdn.detik.net.id/community/media/visual/2023/05/16/makanan-terakhir-7-terpidana-mati-terkenal-kfc-hingga-pizza-hut-1.png?w=700&q=90"
        className="object-cover rounded-lg xl:w-1/3 xl:h-max aspect-video"
        alt="Headline"
      />
      <div className="flex flex-col gap-2 h-max xl:gap-4">
        <span className="flex gap-2">
          <p className="px-4 py-2 border border-text-gray rounded-3xl w-max text-size-content-sm">
            Tragedi
          </p>
          <p className="px-4 py-2 border border-text-gray rounded-3xl w-max text-size-content-sm">
            Kejadian
          </p>
          <p className="px-4 py-2 border border-text-gray rounded-3xl w-max text-size-content-sm">
            Trending
          </p>
        </span>
        <Link to="/blogs/details">
          <p className="font-bold transition text-size-header-content hover:text-red-logo">
            Makanan Terakhir Terpidana Mati hingga Masak Indomie Persis Gambar
            Kemasan
          </p>
        </Link>
        <main className="flex flex-col gap-4 text-text-gray text-size-content ">
          <p className="line-clamp-3 xl:line-clamp-5">
            Jakarta - Para terpidana mati ini memiliki permintaan makanan
            terakhir sebelum dieksekusi. Efek minum kopi 3 kali sehari hingga
            ibu Jepang masak Indomie persis kemasan. Para terpidana mati
            terkenal di Amerika Serikat diberi kesempatan untuk meminta makanan
            terakhir yang akan mereka santap sebelum dieksekusi mati. Seperti
            Robert Alton Harris yang meminta pesta makanan enak dengan menu KFC,
            pizza, hingga es krim.
          </p>
        </main>
      </div>
    </div>
  );
}
