import React, { useEffect } from "react";
// Importing AOS library
import AOS from "aos";
import "aos/dist/aos.css";
import { Link } from "react-router-dom";

export default function BlogCard(props) {
  // Initialize AOS library using useEffect with [] dependency
  useEffect(() => {
    AOS.init({ once: true });
  }, []);

  return (
    <div
      className="flex flex-col gap-2 pb-4 bg-white rounded-lg"
      data-aos="fade-right"
      data-aos-delay={props.delay}
    >
      <img
        src={props.src}
        className="object-cover w-full rounded-t-lg aspect-video"
        alt={props.title}
      />
      <div className="flex flex-col gap-2 px-4">
        <p className="overflow-hidden font-bold text-size-title text-ellipsis line-clamp-2">
          {props.title}
        </p>
        <p className="text-size-content text-text-gray line-clamp-2">
          {props.content[0]}
        </p>
        <Link to="/blogs/details">
          <p className="text-red-logo text-size-content hover:text-red-hover">
            Baca Sekarang
          </p>
        </Link>
      </div>
    </div>
  );
}
