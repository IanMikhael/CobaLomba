import React from "react";
import Time from "../Icons/Time";
const { dataBlogs } = require("../../Data");

export default function BlogsContent() {
  return (
    <div className="flex flex-col gap-8 xl:flex-row containers">
      <div className="flex flex-col order-2 gap-4 xl:order-1 xl:w-3/4">
        <p className="font-bold text-size-title text-red-logo">Hobi & Resep</p>
        <div className="grid grid-cols-2 gap-4 xl:grid-cols-3 xl:gap-4">
          {dataBlogs
            .filter((data) => data.tags.includes("Resep"))
            .map((data, index) => (
              <div
                key={index}
                className="flex flex-col w-full gap-2 pb-2 rounded-lg"
              >
                <img
                  src={data.src}
                  className="object-cover rounded-lg aspect-video"
                  alt={data.title}
                />
                <div className="flex items-center gap-1 px-2">
                  <Time />
                  <p className="text-size-content-sm">
                    {data.timeToRead} Menit
                  </p>
                </div>
                <p className="px-2 font-bold text-size-title line-clamp-2">
                  {data.title}
                </p>
                <p className="px-2 text-text-gray text-size-content line-clamp-3">
                  {data.content[0]}
                </p>
              </div>
            ))}
        </div>
      </div>
      <div className="flex flex-col order-1 gap-4 xl:order-2 xl:w-1/4">
        <p className="font-bold text-size-title text-red-logo">Blog Terbaru</p>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-1 xl:gap-4">
          {dataBlogs
            .filter((data) => data.tags.includes("Terbaru"))
            .map((data, index) => (
              <div
                className="relative flex flex-row items-center gap-2 "
                key={index}
              >
                <img
                  src={data.src}
                  className="object-contain w-full rounded-lg xl:w-1/3 "
                  alt={data.title}
                />
                <div className="absolute bottom-0 w-full h-full xl:relative xl:flex xl:items-center">
                  <div className="absolute inset-0 rounded-lg bg-gradient-to-b from-transparent to-black xl:hidden" />
                  <div className="absolute bottom-0 flex flex-col gap-2 p-4 text-white xl:relative xl:p-0 xl:text-black xl:gap-0">
                    <p className="line-clamp-2">{data.title}</p>
                    <p className="text-gray-300 text-size-content-sm xl:text-text-gray">
                      {data.timeToRead} hari lalu
                    </p>
                  </div>
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}
