import React, { useEffect } from "react";
import BlogCard from "./BlogCard";

// Importing AOS library
import AOS from "aos";
import "aos/dist/aos.css";
import { Link } from "react-router-dom";

const { dataBlogs } = require("../../Data");

export default function Blogs() {
  // Initialize AOS library using useEffect with [] dependency
  useEffect(() => {
    AOS.init({ once: true });
  }, []);

  return (
    <div className="flex flex-col gap-4 containers">
      <p className="font-bold text-center text-size-header" data-aos="fade-up">
        Blog Terkait Mi
      </p>
      <div className="grid gap-4 grid-cols-menu-sm">
        {dataBlogs
          .filter((data, index) => index < 3)
          .map((e, index) => (
            <BlogCard {...e} key={index} delay={100 * (index + 2)} />
          ))}
      </div>
      <Link to="/blogs" className="mx-auto">
        <button className="red-outline-btn w-max " data-aos="fade-right">
          Lihat Semua
        </button>
      </Link>
    </div>
  );
}
