import React from "react";
import Logo from "../../Assets/Logo1.png";

const { dataQuickLinks, dataFollowUs } = require("../../Data");
// const { dataQuickLinks, dataSupports, dataFollowUs } = require("../../Data");

export default function Footer() {
  return (
    <div className="flex flex-col gap-4 pt-8 bg-white sm:pt-16">
      <div className="flex flex-col gap-4 containers xl:flex-row xl:gap-0 ">
        {/* Image and description */}
        <div className="flex flex-col items-center gap-2 text-center xl:w-5/12 xl:text-left xl:items-start ">
          <div className="flex items-center gap-2">
            <img src={Logo} alt="Rasa Palembang Logo" className="w-20 xl:w-22" />
            <p className="text-xl font-bold text-red-logo xl:text-2xl">
              Rasa Palembang
            </p>
          </div>
          <p className="text-sm text-text-gray xl:pr-16">
            6CQG+MHP, Krodan, Maguwoharjo, Kec. Depok, Kabupaten Sleman, Daerah Istimewa Yogyakarta 55281
          </p>
        </div>

        <div className="flex flex-col w-1/3 gap-2 md:w-full">
              <p className="text-sm font-bold">Lokasi:</p>
              <iframe
                title="Rasa Palembang Map"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1582.4480912738728!2d110.431472058213!3d-7.767203244615188!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e7a57a534c8a6af%3A0xf9a7dbf837e9bfda!2sRasa%20Palembang!5e0!3m2!1sen!2sid!4v1675440067575!5m2!1sen!2sid"
                width="50%"
                height="200"
                style={{ border: 0 }}
                allowFullScreen=""
                loading="lazy"
              ></iframe>
            </div>

        <div className="flex flex-col gap-3 md:flex-row xl:w-3/6 xl:gap-0">
          {/* Left Side */}
          <div className="flex xl:w-1/2 md:w-2/3">
            {/* Quick Links */}
            <div className="flex flex-col w-1/2 gap-4">
              <p className="text-sm font-bold">Quick Links</p>
              <ul className="flex flex-col gap-3 text-sm text-text-gray sm:text-base">
                {dataQuickLinks.map((e, index) => (
                  <a href={e.link} key={index}>
                    <li className="transition hover:text-black">{e.title}</li>
                  </a>
                ))}
              </ul>
            </div>

            {/* Support Links */}
            {/* <div className="flex flex-col w-1/2 gap-2">
              <p className="text-sm font-bold">Supports</p>
              <ul className="flex flex-col gap-2 text-sm text-text-gray sm:text-base">
                {dataSupports.map((e, index) => (
                  <a href={e.link} key={index}>
                    <li className="transition hover:text-black">{e.title}</li>
                  </a>
                ))}
              </ul>
            </div> */}
            
            
          </div>

          {/* Right Side */}
          <div className="flex xl:w-1/2 md:flex-col md:gap-8 md:w-1/3">
            {/* Follow us */}
            <div className="flex flex-col w-1/2 gap-2 md:w-full">
              <p className="text-sm font-bold">Follow Us</p>
              <ul className="flex gap-4">
                {dataFollowUs.map((e, index) => (
                  <a href={e.link} key={index}>
                    <li>
                      <img src={e.source} alt={e.alt} />
                    </li>
                  </a>
                ))}
              </ul>
            </div>
            {/* Jam Buka */}
            <div className="flex flex-col w-1/2 gap-2 md:w-full">
              <p className="text-sm font-bold">Jam Buka:</p>
              <p className="flex gap-2 text-sm sm:text-base text-text-gray">
                <span>Setiap Hari</span>
                <span>09.00 - 21.00 WIB</span>
              </p>
            </div>

          </div>
        </div>
      </div>


      <div className="py-4 border-t">
        <p className="text-sm text-center text-text-gray">
          © Rasa Palembang | 2024.
        </p>
      </div>
    </div>
  );
}
