import React, { useEffect } from "react";
import AOS from "aos";
import "aos/dist/aos.css";

export default function MengapaKamiCard(props) {
  useEffect(() => {
    AOS.init({ once: true });
  }, []);

  return (
    <div
      className="flex items-center gap-4 p-2 bg-white rounded-lg"
      data-aos="fade-right"
      data-aos-delay={props.delay}
    >
      <img
        src={props.pict}
        alt={props.alt}
        className="w-20 p-4 border rounded-lg sm:w-auto"
      />
      <div>
        <p className="font-bold text-size-title">{props.title}</p>
        <p className="text-text-gray text-size-content">{props.desc}</p>
      </div>
    </div>
  );
}
