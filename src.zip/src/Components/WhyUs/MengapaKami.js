import React, { useEffect } from "react";
import { dataMengapaKami } from "../../Data";
import MengapaKamiProfile from "../../Assets/MengapaKamiProfile.png";

import MengapaKamiCard from "./MengapaKamiCard";

// Importing AOS library
import AOS from "aos";
import "aos/dist/aos.css";

export default function MengapaKami() {
  // Initialize AOS library using useEffect with [] dependency
  useEffect(() => {
    AOS.init({ once: true });
  }, []);

  return (
    <div
      className="flex flex-col items-center justify-between gap-4 containers md:flex-row xl:pt-16"
      id="mengapaKami"
    >
      <p
        className="font-bold text-center text-size-header md:hidden"
        data-aos="fade-right"
      >
        Mengapa Kami?
      </p>
      <div>
        <img
          src={MengapaKamiProfile}
          alt="Mengapa Kami"
          className="w-3/4 mx-auto sm:w-full"
          data-aos="fade-right"
        />
      </div>

      <div className="flex flex-col gap-8 xl:w-7/12 md:w-2/3">
        <p
          className="hidden font-bold text-center text-size-header md:block"
          data-aos="fade-up"
        >
          Mengapa Kami?
        </p>
        {/* Render Card */}
        <div className="flex flex-col gap-4">
          {dataMengapaKami.map((e, index) => (
            <MengapaKamiCard {...e} delay={100 * index} key={index} />
          ))}
        </div>
      </div>
    </div>
  );
}
