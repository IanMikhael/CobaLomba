import React, { useEffect, useState } from "react";
// import profil1 from "../../Assets/Profil1.jpeg";
import heroImage from "../../Assets/Menu_Compressed/MiKuahBumbuKari.png";
import heroDecor from "../../Assets/HeroDecor.svg";
import HeroReview from "./HeroReview";

// Importing AOS library
import AOS from "aos";
import "aos/dist/aos.css";
import { Link } from "react-router-dom";
import './style.css';

// Importing data dummy
// const { dataReview } = require("../../Data");
const TypingText = ({ texts }) => {
  const [currentTextIndex, setCurrentTextIndex] = useState(0);
  const [currentText, setCurrentText] = useState("");
  const [isTyping, setIsTyping] = useState(true);

  useEffect(() => {
    let index = 0;
    let interval;

    const startTyping = () => {
      interval = setInterval(() => {
        setCurrentText((prevText) => {
          const newText = texts[currentTextIndex].substring(0, index);
          index++;

          if (index > texts[currentTextIndex].length) {
            clearInterval(interval);

            setTimeout(() => {
              index = 0;
              setCurrentText("");
              setIsTyping(true);
              setCurrentTextIndex((prevIndex) =>
                (prevIndex + 1) % texts.length
              );
            }, 1000); // Atur durasi sebelum memulai typing kembali (dalam milidetik)
          }

          return newText;
        });
      }, 100);
    };

    if (isTyping) {
      startTyping();
      setIsTyping(false);
    }

    return () => clearInterval(interval);
  }, [isTyping, texts, currentTextIndex]);

  useEffect(() => {
    setIsTyping(true); // Setiap kali index teks diubah, atur isTyping ke true untuk memulai animasi typing baru
  }, [currentTextIndex, texts]);

  return <span className="text-red-500">{currentText}</span>;
};



export default function Hero() {
  // Initialize AOS library using useEffect with [] dependency
  useEffect(() => {
    AOS.init({ once: true });
  }, []);

  return (
    <main className="flex flex-col items-center gap-16 px-3 md:flex-row sm:px-6 lg:px-8 xl:px-16 md:gap-0">
      {/* Header text section */}
      <section className="flex flex-col order-2 w-full gap-4 md:order-1 md:w-1/2">
        <p
          className="font-bold text-center sm:text-left text-size-hero"
          data-aos="fade-up"
        >
          Cobain dan Rasakan<br />
          Ciri Khas Palembang di{" "}
          <span className="text-red-500">
          {/* <TypingText texts={["Rasa Palembang", "Yogyakarta"]} /> */}
          <TypingText texts={["Rasa Palembang", "Yogyakarta!"]} />
          </span>
        </p>
        <p
          className="text-center text-size-hero-content text-text-gray sm:text-left"
          data-aos="fade-up"
          data-aos-delay="250"
        >
          "Gaskeun, rasain kejutan rasa unik di setiap hidangan! Setiap gigitan atau tegukan beneran bawa kita ke Palembang vibes,
           bro! Langsung cobain, ga bakal nyesel!"
        </p>
        <div className="flex justify-center gap-2 sm:justify-start">
          {/* Button section */}
          <Link
            to="/store"
            className="red-btn-xl bg-red-500 hover:bg-red-700"
            data-aos="fade-up"
            data-aos-delay="300"
          >
            Beli sekarang!
          </Link>
          <Link
            to="/reserve"
            className="px-3 py-3 text-sm transition bg-white rounded-2xl w-max text-black-logo hover:bg-red-700 hover:text-white"
            data-aos="fade-up"
            data-aos-delay="350"
          >
            Reservasi
          </Link>
        </div>
        <HeroReview />
      </section>

      {/* Animated hero image section */}
      <section
        className="relative order-1 w-full h-max md:order-2 md:w-1/2"
        data-aos="fade-left"
        data-aos-delay="250"
      >
       <img
        src={heroImage}
        alt="A delicious food moving up and down slowly..."
        style={{
          transform: "translateY(-40px)",
          animation: "moveUpDown 3s infinite ease-in-out",
        }}
        className="xl:max-w-[500px] w-3/5 h-auto m-auto z-20 relative animate-moveUpDown"
      />

      <img
        src={heroDecor}
        alt="Leaves and chili around the plate"
        style={{
          animation: "moveUpDown 3s infinite ease-in-out",
        }}
        className="absolute top-0 bottom-0 left-0 right-0 w-5/6 m-auto animate-moveUpDown"
      />

        {/* User review card section */}
        {/* <div className="absolute z-20 flex flex-col gap-2 px-4 py-2 bg-white -bottom-8 xl:bottom-0 xl:gap-4 w-max rounded-2xl">
          <div className="flex items-center gap-2">
            <img
              src={profil1}
              alt="Lisa Pramita"
              className="object-cover w-8 h-8 overflow-hidden rounded-full sm:w-12 sm:h-12"
            />
            <div>
              <p className="font-semibold text-size-content sm:text-lg">
                {dataReview.name}
              </p>
              <p className="text-size-content-sm">{dataReview.location}</p>
            </div>
          </div>
          <p className="text-size-content">{dataReview.message}</p>
        </div> */}
      </section>
    </main>
  );
}
