import React, { useEffect } from "react";
import CustomerGroup from "../../Assets/CustomerGroup.png";
import Star from "../Icons/Star";
import AOS from "aos";
import "aos/dist/aos.css";

export default function HeroReview() {
  useEffect(() => {
    AOS.init({ once: true });
  }, []);

  return (
    <div
      className="flex items-center gap-1 mx-auto sm:mx-1"
      data-aos="fade-up"
      data-aos-delay="400"
    >
      {/* <img src={CustomerGroup} alt="Customers" className="w-32 sm:w-auto border-none " /> */}
      {/* <div>
        <p className="text-sm font-bold sm:text-base">Pelanggan Rasa Palembang</p>
        <div className="flex gap-1">
          <Star color="#ffe234" />
          <p className="text-sm text-text-gray sm:text-base">
            4.9 (1.7k Reviews)
          </p>
        </div>
      </div> */}
    </div>
  );
}
