import { Link, useLocation } from "react-router-dom";

export default function NavbarSide(props) {
  const location = useLocation();

  const { data } = props;
  return (
    <aside
      className={`absolute right-0 w-1/3 mr-4 bg-white border top-16 rounded-xl h-max animate-fade-in `}
    >
      {/* Render navigation lists */}
      <ul className="flex flex-col">
        {data.map((elements, index) => (
          <Link
            to={elements.link}
            className={`p-4 hover:bg-slate-50 hover:rounded-xl `}
            key={index}
          >
            <li
              className={`w-max ${
                elements.link === location.pathname
                  ? "text-red-logo border-b-2 border-red-500"
                  : null
              }`}
            >
              {elements.title}
            </li>
          </Link>
        ))}
      </ul>
    </aside>
  );
}
