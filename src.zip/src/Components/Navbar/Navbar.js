// Importing all dependencies
import { useEffect, useRef, useState } from "react";
import NavbarSide from "./NavbarSide";
import HamburgerIcon from "../Icons/Hamburger";
import CartIcon from "../Icons/Cart";
import Logo from "../../Assets/Logo1.png";
import { Link, useLocation } from "react-router-dom";

// Importing data dummy
const { dataNavbar } = require("../../Data");

export default function Navbar(props) {
  const location = useLocation();

  // Set the display of the navigation
  const [isDisplay, setDisplay] = useState(false);

  const clickHandler = () => {
    setDisplay(!isDisplay);
  };

  let navRef = useRef();

  // Using effect for handle close navigation when clicked outside
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (navRef.current && !navRef.current.contains(e.target))
        setDisplay(false);
    };
    document.addEventListener("mousedown", handleClickOutside);
  }, []);

  //  Render cart icon
  const Cart = (
    <div
      className="relative cursor-pointer"
      onClick={() => props.cartOnClick(!props.onShow)}
    >
      <CartIcon />
      {/* Render the cart quantity circle if the cart has items */}
      {props.q > 0 ? (
        <div className="absolute w-4 h-4 text-xs text-white rounded-full bg-red-500 flex-center -top-1 -right-1">
          {props.q}
        </div>
      ) : null}
    </div>
  );

  return (
    <nav className="fixed z-[60] flex items-center justify-between w-full px-4 py-4 backdrop-blur-xl sm:px-6 lg:px-8 xl:px-16" style={{ background: 'rgba(255, 255, 255, 0.75)' }}>
      {/* Logo image section linked to home page */}
      <Link to="/">
        <section className="flex items-center gap-2">
          <img src={Logo} width="55px" alt="Logo Rasa Palembang" />
          <p className="text-2xl font-bold sm:text-3xl text-red-500">Rasa Palembang</p>
        </section>
      </Link>

      {/* List of navigations links */}
      <section className={`flex  ${location.pathname === "/store" ? "gap-14" : "gap-0"}`}>
        <ul className="hidden gap-14 sm:flex">
          {dataNavbar.map((elements, index) => (
            <Link
              to={elements.link}
              className={`transition hover:text-red-logo ${
                elements.link === location.pathname
                  ? "text-red-logo border-b-2 border-red-logo"
                  : null
              }`}
              key={index}
            >
              <li key={index}>{elements.title}</li>
            </Link>
          ))}
        </ul>

        {/* Render cart icon when location url is /store */}
        <section className="hidden sm:block">
          {location.pathname === "/store" ? Cart : null}
        </section>

        {/* Render navigation side when in mobile view and hamburger icon is clicked */}
        <section className="sm:hidden" ref={navRef}>
          <div className="flex gap-4">
            {location.pathname === "/store" ? Cart : null}
            <HamburgerIcon isClicked={clickHandler} />
          </div>
          {isDisplay ? <NavbarSide data={dataNavbar} isDisplay /> : null}
        </section>
      </section>
    </nav>
  );
}
