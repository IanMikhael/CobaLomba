import React, { useEffect, useRef, useState } from "react";

export default function PaymentCard(props) {
  const [selectedOption, setSelectedOption] = useState(null);
  const activeOption = useRef();

  const handleOptionChange = () => {
    setSelectedOption(activeOption.current.value);
  };

  useEffect(() => {
    setSelectedOption(activeOption.current.value);
  }, []);

  return (
    <label
      htmlFor={props.id}
      className={`p-4 border-2 rounded-lg flex justify-between items-center h-16 ${
        selectedOption === props.id ? "border" : "border"
      }`}
    >
      <img src={props.img} className="w-16" alt={props.id} />
      <input
        type="radio"
        id={props.id}
        className="text-red-logo focus:ring-red-logo form-radio"
        name="metode-pembayaran"
        value={props.id}
        onChange={handleOptionChange}
        ref={activeOption}
      />
    </label>
  );
}
