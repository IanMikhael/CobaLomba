import React from "react";
import PaymentCard from "./PaymentCard";
export default function Method() {
  const dataMetodePembayaran = [
    {
      id: "bca",
      img: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5c/Bank_Central_Asia.svg/2560px-Bank_Central_Asia.svg.png",
    },
    {
      id: "gopay",
      img: "https://1.bp.blogspot.com/-NwSMFZdU8l4/XZxj8FxN6II/AAAAAAAABdM/oTjizwstkRIqQZ7LOZSPMsUG3EYXF3E4wCEwYBhgL/s1600/logo-gopay-vector.png",
    },
    {
      id: "shopeepay",
      img: "https://1.bp.blogspot.com/-n_jPjNl97nw/YIJ78WnloPI/AAAAAAAACks/xPjLQ2YpcXwyPf64C708UExQOrJitxHSgCNcBGAsYHQ/w1200-h630-p-k-no-nu/ShopeePay.png",
    },
    {
      id: "dana",
      img: "https://upload.wikimedia.org/wikipedia/commons/thumb/7/72/Logo_dana_blue.svg/2560px-Logo_dana_blue.svg.png",
    },
  ];

  return (
    <div className="flex flex-col w-full gap-4 p-4 bg-white rounded-lg lg:p-8">
      <p className="font-bold text-size-title">Metode Pembayaran</p>
      <div className="flex flex-col gap-2 ">
        {dataMetodePembayaran.map((e) => (
          <PaymentCard {...e} />
        ))}
      </div>
    </div>
  );
}
