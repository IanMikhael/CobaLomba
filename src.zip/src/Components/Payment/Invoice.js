import React from "react";
import Document from "../Icons/Document";
import DateIcon from "../Icons/Date";

export default function Invoice(props) {
  const { data } = props;
  console.log(data[0]);

  const today = new Date();
  const options = { day: "2-digit", month: "2-digit", year: "numeric" };
  const formattedDate = today.toLocaleDateString("en-US", options).split("/");

  const rupiah = (number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
    }).format(number);
  };
  return (
    <div className="p-4 bg-white rounded-lg lg:p-8">
      <div className="flex items-center gap-4 pb-4 mb-4 border-b-2">
        <Document />
        <div>
          <p className="font-bold text-size-title ">
            Pesanan Nomor #{formattedDate}-00001
          </p>
          <span className="flex gap-2 text-text-gray">
            <DateIcon />
            <p className="text-size-content">{formattedDate.join("-")}</p>
          </span>
        </div>
      </div>
      <div>
        <table className="w-full text-center text-size-content">
          <tr>
            <th className="w-1/2 ">Produk</th>
            <th className="w-1/4 ">Jumlah</th>
            <th className="w-1/4 ">Harga</th>
          </tr>
          {Object.entries(data).map(([key, value]) => {
            if (key !== "totalPrice") {
              return (
                <tr className=" text-text-gray" key={key}>
                  <td className="justify-start w-full gap-4 flex-center">
                    <img
                      src={value.src}
                      className="object-contain w-16 aspect-square"
                      alt={value.name}
                    />
                    <p>{value.name}</p>
                  </td>
                  <td>{value.q} Porsi</td>
                  <td>{rupiah(value.price)}</td>
                </tr>
              );
            }
            return null;
          })}

          {/* <tr className="mt-4 border-t-2 text-text-gray">
            <td className="py-2 mt-4 text-left">Subtotal</td>
            <td></td>
            <td>{rupiah(data.totalPrice)}</td>
          </tr>
          <tr className="text-text-gray">
            <td className="py-2 text-left">Diskon</td>
            <td></td>
            <td>Rp 0,0</td>
          </tr> */}
          <tr className="border-t-2 text-text-gray columns-4">
            <td className="py-2 font-bold text-left text-black">Subtotal</td>
            <td></td>
            <td className="font-bold text-black">{rupiah(data.totalPrice)}</td>
          </tr>
        </table>
      </div>
    </div>
  );
}
