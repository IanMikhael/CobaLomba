import React from "react";

export default function FoodDelivery() {
  const dataDelivery = [
    {
      id: "dinein",
      title: "Dine In",
    },
    {
      id: "takeaway",
      title: "Take Away",
    },
  ];
  return (
    <div className="flex flex-col gap-4 p-4 bg-white rounded-lg lg:p-8">
      <div className="flex flex-col gap-2 xl:gap-4">
        <div className="flex gap-8">
          {dataDelivery.map((e) => (
            <span className="flex items-center gap-2">
              <input
                type="radio"
                id={e.id}
                name="foodDeliveryOption"
                className="text-red-logo checked:text-red-logo checked:ring-red-logo"
              />
              <label for={e.id} className="font-bold text-size-title">
                {e.title}
              </label>
            </span>
          ))}
        </div>
        <span className="flex flex-col gap-4">
          <input
            type="text"
            placeholder="Nama"
            className="border-b-2 outline-none focus:border-text-gray text-size-content padding-btn"
          />
          <input
            type="tel"
            placeholder="Nomor Whatsapp"
            className="border-b-2 outline-none focus:border-text-gray text-size-content padding-btn"
          />
          <input
            type="email"
            placeholder="Alamat Email"
            className="border-b-2 outline-none focus:border-text-gray text-size-content padding-btn"
          />
        </span>
      </div>
    </div>
  );
}
