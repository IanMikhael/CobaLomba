import React, { useState, useEffect, useMemo } from "react";
import Alert from "../UI/Alert";
import Barcode from "../../Assets/Barcode.png";

export default function PaymentButton(props) {
  const dataCoupon = useMemo(
    () => [
      {
        code: "HAPPYMAY",
        discount: {
          persentage: 0.7,
          max: 10000,
        },
      },
      {
        code: "ABCFIVE",
        discount: {
          persentage: 0.25,
          max: 30000,
        },
      },
      {
        code: "A",
        discount: 100000,
      },
    ],
    []
  );

  const [showAlert, setShowAlert] = useState(false);

  const handleCloseAlert = () => {
    setShowAlert(false);
  };

  const [couponCode, setCouponCode] = useState("");
  const [message, setMessage] = useState("");
  const [discount, setDiscount] = useState(0);
  const total = props.total;
  const [isValid, setIsValid] = useState(false);

  const handleInputChange = (event) => {
    setCouponCode(event.target.value);
  };

  useEffect(() => {
    const coupon = dataCoupon.find(
      (data) => data.code.toLowerCase() === couponCode.toLowerCase()
    );
    setIsValid(!!coupon);
  }, [couponCode, dataCoupon]);

  const handleApplyCoupon = () => {
    if (isValid) {
      const coupon = dataCoupon.find(
        (data) => data.code.toLowerCase() === couponCode.toLowerCase()
      );
      setMessage("Coupon applied successfully!");
      setTimeout(() => {
        setMessage(""); // Clear the message after 6 seconds
      }, 6000);

      if (coupon.discount) {
        let discount = coupon.discount.persentage
          ? (1 - coupon.discount.persentage) * total
          : coupon.discount;

        discount = Math.min(
          discount,
          coupon.discount.max ? coupon.discount.max : discount,
          total
        );
        setDiscount(discount);
      } else {
        setDiscount(0);
      }
    } else {
      setMessage("Invalid coupon code");
      setDiscount(0);
    }
  };

  useEffect(() => {
    let timer;
    if (message === "Coupon applied successfully") {
      timer = setTimeout(() => {
        setMessage(""); // Clear the message after 6 seconds
      }, 6000);
    }
    return () => {
      clearTimeout(timer);
    };
  }, [message]);

  const rupiah = (number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
    }).format(number);
  };

  return (
    <div className="flex flex-col p-4 bg-white rounded-lg lg:p-8">
      <div className="flex flex-col gap-2 pb-4 mb-4 border-b-2 border-dashed">
        <div className="flex gap-2">
          <input
            className="w-full border rounded-lg outline-none padding-btn text-size-content focus:border-text-gray"
            placeholder="% Kode Kupon"
            value={couponCode}
            onChange={handleInputChange}
          />
          <button
            className="red-outline-btn padding-btn"
            onClick={handleApplyCoupon}
          >
            Apply
          </button>
        </div>
        {message && (
          <p
            className={`text-size-content ${
              message === "Coupon applied successfully!"
                ? "text-green-700"
                : "text-red-logo"
            }`}
          >
            {message}
          </p>
        )}
      </div>

      <div className="flex flex-col gap-4 pb-4 mb-4 border-b-2 border-dashed text-text-gray text-size-content">
        <span className="flex justify-between">
          <p>Subtotal</p>
          <p className="font-medium text-black">{rupiah(props.total)}</p>
        </span>
        <span className="flex justify-between">
          <p>Diskon</p>
          <p className="font-medium text-red-logo ">{rupiah(discount)}</p>
        </span>
        <span className="flex justify-between">
          <p>Total</p>
          <p className="font-medium text-black">{rupiah(total - discount)}</p>
        </span>
      </div>

      <button
        className="w-full red-btn text-size-content"
        onClick={() => setShowAlert(true)}
      >
        Order
      </button>
      {showAlert ? (
        <Alert
          message={{
            title: "9883123456789",
            content: `Lakukan pembayaran melalui scan QR atau transfer ke nomor di atas sebesar ${rupiah(
              total - discount
            )} sebelum waktu pembayaran habis. `,
            additional: {
              text: "Mengalami kendala dalam pembayaran? Hubungi",
              link: "0812-1234-1243",
            },
            barcode: Barcode,
          }}
          onClose={handleCloseAlert}
        />
      ) : null}
    </div>
  );
}
