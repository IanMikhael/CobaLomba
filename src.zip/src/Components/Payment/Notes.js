import React from "react";

export default function Notes() {
  return (
    <div className="flex flex-col gap-4 p-4 bg-white rounded-lg lg:p-8">
      <p className="font-bold text-size-title">Catatan</p>
      <textarea
        className="w-full p-2 border rounded-lg text-size-content focus:outline-none focus:border-text-gray h-32"
        placeholder="Tuliskan catatan tentang menu kamu bagi kami."
      />
    </div>
  );
}
