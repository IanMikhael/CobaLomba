import InstagramIcon from "./Assets/Brands/Instagram.svg";
import TwitterIcon from "./Assets/Brands/Twitter.svg";
import FacebookIcon from "./Assets/Brands/Facebook.svg";
import TelegramIcon from "./Assets/Brands/Telegram.svg";

import ImageMudah from "./Assets/MengapaKami/Mudah.svg";
import ImageMurah from "./Assets/MengapaKami/Murah.svg";
import ImageCepat from "./Assets/MengapaKami/Cepat.svg";

import BakmiKomplit from "./Assets/Menu_Compressed/BakmiKomplit.png";
import BakmiKuah from "./Assets/Menu_Compressed/BakmiKuah.png";
import BakmiKuahUdang from "./Assets/Menu_Compressed/BakmiKuahUdang.png";
import BakmiSapi from "./Assets/Menu_Compressed/BakmiSapi.png";
import IndomieGorengCaisim from "./Assets/Menu_Compressed/IndomieGorengCaisim.png";
import IndomiePolos from "./Assets/Menu_Compressed/IndomiePolos.png";
import MiAyamPanggang from "./Assets/Menu_Compressed/MiAyamPanggang.png";
import MiCarbonara from "./Assets/Menu_Compressed/MiCarbonara.png";
import MiDaunJeruk from "./Assets/Menu_Compressed/MiDaunJeruk.png";
import MiGorengJawa from "./Assets/Menu_Compressed/MiGorengJawa.png";
import MiGorengSambalMatah from "./Assets/Menu_Compressed/MiGorengSambalMatah.png";
import MiGorengTelurSambalMatah from "./Assets/Menu_Compressed/MiGorengTelurSambalMatah.png";
import MiGorengTelurSaosSpesial from "./Assets/Menu_Compressed/MiGorengTelurSaosSpesial.png";
import MiKepiting from "./Assets/Menu_Compressed/MiKepiting.png";
import MiKuahAyamKariMerah from "./Assets/Menu_Compressed/MiKuahAyamKariMerah.png";
import MiKuahBumbuKari from "./Assets/Menu_Compressed/MiKuahBumbuKari.png";
import MiKuahKalduSapi from "./Assets/Menu_Compressed/MiKuahKalduSapi.png";
import MiManis from "./Assets/Menu_Compressed/MiManis.png";
import MiNyemekBumbuSapi from "./Assets/Menu_Compressed/MiNyemekBumbuSapi.png";
import MiTelurPuyuh from "./Assets/Menu_Compressed/MiTelurPuyuh.png";

// Import Minuman
import AirMineral from "./Assets/Menu_Compressed/Minuman/AirMineral.png";
import ChocolateMilkShake from "./Assets/Menu_Compressed/Minuman/ChocolateMilkshake.png";
import EsBatu from "./Assets/Menu_Compressed/Minuman/EsBatu.png";
import EsLemonTea from "./Assets/Menu_Compressed/Minuman/EsLemonTea.png";
import EsTeh from "./Assets/Menu_Compressed/Minuman/EsTeh.png";
import OreaMilkShake from "./Assets/Menu_Compressed/Minuman/OreoMilkshake.png";
import StrawberryMilkShake from "./Assets/Menu_Compressed/Minuman/StrawberryMilkshake.png";
import ThaiTea from "./Assets/Menu_Compressed/Minuman/ThaiTea.png";

// import Snack
import BakpaoKacangMerah from "./Assets/Menu_Compressed/SelainMi/BakpaoKacangMerah.png";
import BakpaoTelurAsin from "./Assets/Menu_Compressed/SelainMi/BakpaoTelurAsin.png";
import BolaUdang from "./Assets/Menu_Compressed/SelainMi/BolaUdang.png";
import DimsumPangsit from "./Assets/Menu_Compressed/SelainMi/DimsumPangsit.png";
import DimsumSiomay from "./Assets/Menu_Compressed/SelainMi/DimsumSiomay.png";
import KentangGoreng from "./Assets/Menu_Compressed/SelainMi/KentangGoreng.png";
import Lumpia from "./Assets/Menu_Compressed/SelainMi/Lumpia.png";
import NasiGoreng from "./Assets/Menu_Compressed/SelainMi/NasiGoreng.png";
import OnionRing from "./Assets/Menu_Compressed/SelainMi/OnionRing.png";
import SosisGoreng from "./Assets/Menu_Compressed/SelainMi/SosisGoreng.png";

// Import Testimonial
import P1 from "./Assets/Testimonial/P1.jpeg";
import P2 from "./Assets/Testimonial/P2.jpg";
import P3 from "./Assets/Testimonial/P3.jpg";
import P4 from "./Assets/Testimonial/P4.png";

// Navbar section
const dataNavbar = [
  {
    title: "Home",
    link: "/",
  },
  {
    title: "Menu",
    link: "/store",
  },
  {
    title: "About",
    link: "/blogs",
  },
  {
    title: "Reservasi",
    link: "/reserve",
  },
];

// Hero section
const dataReview = {
  name: "Lisa Pramita",
  location: "Yogyakarta, 2023",
  message: "Untuk Rasa Gak Ada Lawan Deh!",
};

const dataMengapaKami = [
  {
    title: "Mudah",
    desc: "MiTime beroperasi menggunakan layanan situs web yang mudah digunakan oleh seluruh kalangan",
    pict: ImageMudah,
    alt: "Mudah",
  },
  {
    title: "Murah",
    desc: "MiTime memberikan penawaran berbagai produk mi dengan harga yang terjangkau",
    pict: ImageMurah,
    alt: "Murah",
  },
  {
    title: "Cepat",
    desc: "MiTime menyediakan layanan pemesanan produk secara digital, sehingga konsumen dapat memesan produk dari perjalanan tanpa mengantre di tempat",
    pict: ImageCepat,
    alt: "Cepat",
  },
];

// Menu Section
const dataButton = [
  {
    title: "Menu Favorite",
    status: true,
  },
  {
    title: "Menu Terbaru",
    status: false,
  },
  {
    title: "Menu Terlaris",
    status: false,
  },
];

const dataMenu = [
  {
    name: "Bakmi Komplit",
    desc: "Mi Lezat dengan Topping Variatif. Rasakan Kelezatan Mi Sempurna. Paduan Nikmat Mi, Daging, dan Sayuran.",
    cat: "Menu Favorite",
    price: 20000,
    q: 0,
    src: BakmiKomplit,
  },
  {
    name: "Bakmi Kuah",
    desc: "Kelezatan Mi dalam Kuah Gurih. Sensasi Rasanya Menggugah Selera. Sajian Mi Lezat dengan Aroma Menggoda.",
    cat: "Menu Favorite",
    price: 15000,
    q: 0,
    src: BakmiKuah,
  },
  {
    name: "Bakmi Kuah Udang",
    desc: "Kombinasi Nikmat Mi dan Udang Segar. Kelezatan Rasa yang Menggoda Selera.",
    cat: "Menu Favorite",
    price: 25000,
    q: 0,
    src: BakmiKuahUdang,
  },
  {
    name: "Bakmi Sapi",
    desc: "Sajian Mi Gurih dengan Potongan Sapi yang Empuk. Kenikmatan yang Mengenyangkan.",
    cat: "Menu Favorite",
    price: 35000,
    q: 0,
    src: BakmiSapi,
  },
  {
    name: "Indomie Goreng Caisim",
    desc: "Mi instan populer yang terdiri dari mi goreng, potongan caisim, dan bumbu rempah. Dalam setiap gigitannya, Anda akan merasakan kelezatan mi yang renyah dan kaya rasa, serta rasa segar dari caisim yang memberikan keseimbangan sempurna pada cita rasa mie.",
    cat: "Menu Terlaris",
    price: 19000,
    q: 0,
    src: IndomieGorengCaisim,
  },
  {
    name: "Indomie Polos",
    desc: "Mi instan yang terkenal dengan kesederhanaannya. Dengan hanya menggunakan mi tanpa tambahan bumbu atau topping, Indomie Polos mempersembahkan cita rasa mi yang autentik dan lezat.",
    cat: "Menu Terlaris",
    price: 10000,
    q: 0,
    src: IndomiePolos,
  },
  {
    name: "Mi Ayam Panggang",
    desc: "Hidangan yang lezat dan menggugah selera dengan kombinasi mi kenyal yang disajikan dengan potongan ayam panggang yang juicy dan berbagai bumbu yang khas. Rasakan kelezatan mi yang lezat dan kenyal yang dipadukan dengan cita rasa ayam panggang yang sempurna.",
    cat: "Menu Terlaris",
    price: 18000,
    q: 0,
    src: MiAyamPanggang,
  },
  {
    name: "Mi Carbonara",
    desc: "Hidangan pasta klasik yang memikat selera dengan paduan sempurna mi al dente yang dilumuri dengan saus creamy dan gurih.",
    cat: "Menu Terlaris",
    price: 16000,
    q: 0,
    src: MiCarbonara,
  },
  {
    name: "Mi Daun Jeruk",
    desc: "Aroma segar daun jeruk, cita rasa yang menyegarkan. Kenikmatan mi dengan sentuhan jeruk. Rasakan kelezatan mi daun jeruk yang menggugah selera.",
    cat: "Menu Terbaru",
    price: 15000,
    q: 0,
    src: MiDaunJeruk,
  },
  {
    name: "Mi Goreng Jawa",
    desc: "Paduan cita rasa tradisional Jawa. Mi yang digoreng dengan rempah khas Jawa. Rasakan sensasi gurih dan pedasnya mi goreng Jawa.",
    cat: "Menu Terbaru",
    price: 18000,
    q: 0,
    src: MiGorengJawa,
  },
  {
    name: "Mi Sambal Matah",
    desc: "Kombinasi sempurna antara mi yang lezat dan sambal matah yang segar. Nikmati keharmonisan cita rasa mi yang kenyal dengan sensasi pedas dan segar dari sambal matah.",
    cat: "Menu Terbaru",
    price: 24000,
    q: 0,
    src: MiGorengSambalMatah,
  },
  {
    name: "Mi Telur Sambal Matah",
    desc: "Gabungan istimewa antara mi, telur, dan sambal matah yang menggoda selera. Rasakan kelezatan mi yang lezat dengan tambahan telur yang menggiurkan, dilengkapi dengan aroma dan rasa segar dari sambal matah yang khas.",
    cat: "Menu Terbaru",
    price: 28000,
    q: 0,
    src: MiGorengTelurSambalMatah,
  },
  {
    name: "Mi Goreng Telur Saos Spesial",
    desc: "Perpaduan mi goreng yang renyah dan lezat, serta telur yang dimasak dengan sempurna. Hidangan ini diberi sentuhan khusus dengan saos spesial yang memberikan rasa pedas dan gurih yang menggoda selera.",
    cat: "Menu Terbaru",
    price: 15000,
    q: 0,
    src: MiGorengTelurSaosSpesial,
  },
  {
    name: "Mi Kepiting",
    desc: "Sensasi gurih dan manis dari daging kepiting yang segar, yang melengkapi mi dengan cita rasa laut yang khas. Pilihan sempurna bagi pecinta seafood yang ingin menikmati hidangan mi yang lezat dan memuaskan.",
    cat: "Menu Terbaru",
    price: 42000,
    q: 0,
    src: MiKepiting,
  },
  {
    name: "Mi Kuah Ayam Kari Merah",
    desc: "Hidangan mi dengan kuah kari merah yang menggugah selera. Mi kenyal disajikan dalam kuah kari yang kaya akan rasa dan aroma rempah.",
    cat: "Menu Favorite",
    price: 24000,
    q: 0,
    src: MiKuahAyamKariMerah,
  },
  {
    name: "Mi Kuah Bumbu Kari",
    desc: "Sensasi kelezatan mi yang terendam dalam kuah kari bumbu yang kaya dan nikmati kombinasi unik rasa rempah dan kelezatan mi dalam setiap suapan. Mi Kuah Bumbu Kari adalah pilihan yang sempurna untuk memuaskan selera mi dan pencinta hidangan berkuah.",
    cat: "Menu Favorite",
    price: 22000,
    q: 0,
    src: MiKuahBumbuKari,
  },
  {
    name: "Mi Kuah Kaldu Sapi",
    desc: "Mi yang kenyal direndam dalam kuah kaldu sapi yang kaya rasa, memberikan sensasi kehangatan dan kelezatan di setiap suapan.",
    cat: "Menu Favorite",
    price: 27000,
    q: 0,
    src: MiKuahKalduSapi,
  },
  {
    name: "Mi Manis",
    desc: "Mi dengan cita rasa manis yang menggoda selera. Mi yang lezat dan kenyal diolah dengan saus manis yang kaya rasa, memberikan sentuhan manis yang menyenangkan di setiap gigitan.",
    cat: "Menu Favorite",
    price: 18000,
    q: 0,
    src: MiManis,
  },
  {
    name: "Mi Nyemek Bumbu Sapi",
    desc: "Mi dengan kuah gurih yang kaya akan rasa sapi yang lezat. Pilihan yang sempurna untuk Anda yang ingin menikmati hidangan mi yang lezat dengan cita rasa sapi yang autentik.",
    cat: "Menu Favorite",
    price: 22000,
    q: 0,
    src: MiNyemekBumbuSapi,
  },
  {
    name: "Mi Telur Puyuh",
    desc: "Mi yang kenyal dan lezat disajikan dengan kuah yang gurih dan bumbu yang kaya, dilengkapi dengan telur puyuh yang dimasak sempurna. Tambahan telur puyuh memberikan sentuhan istimewa pada hidangan ini, memberikan tekstur lembut dan rasa yang lezat.",
    cat: "Menu Terlaris",
    price: 17000,
    q: 0,
    src: MiTelurPuyuh,
  },
  {
    name: "Air Mineral",
    desc: "Minuman yang segar dan menyegarkan untuk menemani hidangan lezat Anda. Air mineral yang disajikan di restoran ini memiliki kualitas terbaik dan terjamin kebersihannya.",
    cat: "Minuman",
    price: 2000,
    q: 0,
    src: AirMineral,
  },
  {
    name: "Chocolate Milk Shake",
    desc: "Terbuat dari sirup cokelat yang kaya, susu dingin, dan satu scoop es krim vanila yang lembut, Chocolate Milk Shake menawarkan pengalaman yang menyegarkan dan memuaskan.",
    cat: "Minuman",
    price: 12000,
    q: 0,
    src: ChocolateMilkShake,
  },
  {
    name: "Es Batu",
    desc: "Tambahkan es batu agar minumanmu semakin segar.",
    cat: "Minuman",
    price: 1000,
    q: 0,
    src: EsBatu,
  },
  {
    name: "Lemon Tea Dingin/Panas",
    desc: "Lemon Tea Dingin/Panas dibuat dengan menggunakan teh pilihan yang diseduh dengan air panas hingga meresap dengan sempurna. Kemudian, ditambahkan dengan perasan air lemon segar yang memberikan rasa asam yang menyegarkan dan aroma yang menggugah selera.",
    cat: "Minuman",
    price: 6000,
    q: 0,
    src: EsLemonTea,
  },
  {
    name: "Teh Dingin/Panas",
    desc: "Teh Dingin/Panas disajikan dengan menggunakan daun teh pilihan yang berkualitas tinggi. Untuk versi dingin, teh diseduh dengan air hangat terlebih dahulu, kemudian disimpan di dalam kulkas atau ditambahkan es batu sehingga menghasilkan minuman yang segar dan menyegarkan.",
    cat: "Minuman",
    price: 4000,
    q: 0,
    src: EsTeh,
  },
  {
    name: "Oreo Milk Shake",
    desc: "Oreo Milk Shake disajikan dalam keadaan dingin, sehingga memberikan sensasi kesegaran yang menyenangkan. Untuk membuatnya, biskuit Oreo dihancurkan dan dicampur dengan susu segar serta es batu. Kemudian, campuran tersebut dikocok atau diblender hingga menjadi tekstur yang lembut dan kental. Hasilnya adalah minuman yang kaya akan rasa cokelat dari biskuit Oreo yang terasa lezat di setiap tegukan.",
    cat: "Minuman",
    price: 12000,
    q: 0,
    src: OreaMilkShake,
  },
  {
    name: "Strawberry Milk Shake",
    desc: "Minuman ini sangat populer di musim panas atau sebagai camilan manis yang menyegarkan. Rasanya yang manis dan segar membuatnya menjadi pilihan favorit bagi pecinta stroberi.",
    cat: "Minuman",
    price: 14000,
    q: 0,
    src: StrawberryMilkShake,
  },
  {
    name: "Thai Tea",
    desc: "Thai Tea dibuat dengan menggunakan teh hitam yang kuat, seperti Assam, yang kemudian dicampur dengan susu kental manis dan bumbu-bumbu khas Thailand. Bumbu utama yang memberikan cita rasa khas pada Thai Tea adalah pandan, daun pandan yang memberikan aroma yang lezat dan warna hijau alami. Selain itu, Thai Tea juga menggunakan gula batu atau gula aren untuk memberikan rasa manis yang khas.",
    cat: "Minuman",
    price: 8000,
    q: 0,
    src: ThaiTea,
  },
  {
    name: "Bakpao Kacang Merah",
    desc: "Bakpao ini adalah hidangan tradisional yang terbuat dari adonan lembut yang diisi dengan kacang merah manis. Dengan cita rasa yang autentik dan tekstur yang kenyal, Bakpao Kacang Merah di MiTime akan memanjakan lidah Anda.",
    cat: "Selain Mi",
    price: 10000,
    q: 0,
    src: BakpaoKacangMerah,
  },
  {
    name: "Bakpao Telur Asin",
    desc: "Bakpao lezat dengan isian saus telur asin dalamnya. Paduan manis dan gurih yang sempurna. Rasakan kelezatan bakpao telur asin Mitime.",
    cat: "Selain Mi",
    price: 20000,
    q: 0,
    src: BakpaoTelurAsin,
  },
  {
    name: "Bola Udang",
    desc: "Perpaduan udang dan roti yang digoreng sempurna. Bola udang garing di luar, lembut di dalam. Perpaduan sempurna tekstur dan rasa udang. Nikmati kelezatan bola udang yang menggugah selera.",
    cat: "Selain Mi",
    price: 20000,
    q: 0,
    src: BolaUdang,
  },
  {
    name: "Dimsum Pangsit",
    desc: "Dimsum pangsit dengan isi lezat di dalamnya. Gigitan pertama mengungkap kelezatan yang memanjakan. Nikmati sensasi dimsum pangsit yang tak terlupakan.",
    cat: "Selain Mi",
    price: 23000,
    q: 0,
    src: DimsumPangsit,
  },
  {
    name: "Dimsum Siomay",
    desc: "Hidangan dimsum Siomay lezat, padat dengan rasa. Gigitan pertama mengungkapkan kelezatan gurihnya. Kreasikan saat menyantap dimsum Siomay.",
    cat: "Selain Mi",
    price: 20000,
    q: 0,
    src: DimsumSiomay,
  },
  {
    name: "Kentang Goreng",
    desc: "Kentang goreng renyah, gurih yang tak terlupakan. Potongan-potongan emas, kesempurnaan dalam setiap gigitan. Nikmati kelezatan kentang goreng yang menggoda.",
    cat: "Selain Mi",
    price: 8000,
    q: 0,
    src: KentangGoreng,
  },
  {
    name: "Lumpia",
    desc: "Lumpia renyah dengan isian lezat di dalamnya. Gigitan pertama mengungkap rasa segar yang memanjakan. Nikmati lumpia yang menggoda selera.",
    cat: "Selain Mi",
    price: 15000,
    q: 0,
    src: Lumpia,
  },
  {
    name: "Nasi Goreng",
    desc: "Nasi goreng yang lezat dan kaya rempah. Gurih dan pedas, menyegarkan selera. Nikmati sensasi cita rasa nasi goreng.",
    cat: "Selain Mi",
    price: 18000,
    q: 0,
    src: NasiGoreng,
  },
  {
    name: "Onion Ring",
    desc: "Onion ring renyah dan gurih yang sempurna. Potongan bawang emas yang menggoda selera. Nikmati kelezatan onion ring yang tak terlupakan.",
    cat: "Selain Mi",
    price: 10000,
    q: 0,
    src: OnionRing,
  },
  {
    name: "Sosis Goreng",
    desc: "Sosis goreng lezat, gurih dalam setiap gigitan. Kerenyahan luar, kelembutan dalamnya. Nikmati sosis goreng yang memanjakan lidah Anda.",
    cat: "Selain Mi",
    price: 15000,
    q: 0,
    src: SosisGoreng,
  },
];

// Reservation Section

// Footer Section
const dataQuickLinks = [
  {
    title: "Home",
    link: "/",
  },
  {
    title: "Store",
    link: "/store",
  },
  {
    title: "Blogs",
    link: "/blogs",
  },
  {
    title: "Reservasi",
    link: "/reserve",
  },
];
const dataSupports = [
  {
    title: "About Us",
    link: "#",
  },
  {
    title: "Contact",
    link: "#",
  },
  {
    title: "Privacy and Policies",
    link: "#",
  },
  {
    title: "Terms and Conditions",
    link: "#",
  },
];
const dataFollowUs = [
  {
    source: InstagramIcon,
    alt: "Instagram",
    link: "#",
  },
  {
    source: FacebookIcon,
    alt: "Facebook",
    link: "#",
  },
  {
    source: TwitterIcon,
    alt: "Twitter",
    link: "#",
  },
  {
    source: TelegramIcon,
    alt: "Telegram",
    link: "#",
  },
];

// Blogs Section
const dataBlogs = [
  {
    id: 1,
    title:
      "Makanan Terakhir Terpidana Mati hingga Masak Indomie Persis Gambar Kemasan",
    src: "https://akcdn.detik.net.id/community/media/visual/2023/05/16/makanan-terakhir-7-terpidana-mati-terkenal-kfc-hingga-pizza-hut-1.png?w=700&q=90",
    tags: ["Tragedi", "Kejadian", "Trending"],
    author: "Yenny Mustika Sari",
    data: "Rabu, 17 Mei 2023 09:30 WIB",
    content: [
      "Pada suatu hari di penjara, seorang terpidana mati yang akan segera dieksekusi diberikan kebebasan untuk memilih makanan terakhirnya. Keputusannya? Mengejutkan! Terpidana mati tersebut memilih untuk memasak mi instan Indomie, persis seperti yang tergambar di kemasannya.",
      "Tindakan ini memicu perbincangan di kalangan petugas penjara dan narapidana lainnya. Beberapa orang heran dengan pilihan makanan yang sederhana, sementara yang lain mempertanyakan mengapa terpidana mati tersebut ingin menyantap mi instan sebagai hidangan terakhirnya.",
      "Bagi terpidana mati tersebut, mi instan Indomie memiliki makna tersendiri. Mungkin rasanya membawa kembali kenangan masa lalu atau mewakili kesederhanaan dalam kehidupan yang tidak lagi dimilikinya. Dalam momen terakhirnya, dia memilih untuk mengenang rasa dan aroma mi instan yang begitu akrab.",
      "Makanan terakhir terpidana mati yang berupa mi instan Indomie ini menjadi perbincangan yang menarik di lingkungan penjara. Meskipun sederhana, pilihan tersebut mengingatkan kita akan kebebasan yang mungkin seringkali diabaikan. Kadang-kadang, kebahagiaan dapat ditemukan dalam hal-hal sekecil memasak mi instan, bahkan di tengah keadaan yang paling sulit sekalipun.",
      "Keputusan terpidana mati untuk memasak mi instan persis seperti gambar kemasan menunjukkan bahwa hidup memiliki cara unik untuk memberikan makna pada setiap momen, termasuk momen terakhir.",
      "Banyak orang di penjara yang terinspirasi oleh keputusan terpidana mati ini. Mereka menyadari bahwa kebahagiaan dan kenikmatan bisa ditemukan dalam hal-hal sederhana yang seringkali dianggap remeh.",
      "Beberapa narapidana lainnya juga mulai memasak mi instan dengan berbagai cara kreatif, menambahkan bumbu dan bahan lain untuk menciptakan rasa yang berbeda. Mereka menggunakan mi instan sebagai medium ekspresi dan pelarian dari keadaan yang sulit.",
      "Penasaran dengan fenomena ini, petugas penjara mendekati narapidana yang memilih mi instan sebagai makanan terakhirnya. Mereka ingin mengetahui alasan di balik pilihan tersebut dan bagaimana mi instan bisa memiliki pengaruh begitu besar di tengah penjara.",
      "Ternyata, mi instan juga menjadi sumber inspirasi bagi para narapidana. Bagi mereka, mi instan mewakili kemampuan untuk menciptakan sesuatu dari yang sederhana. Dalam dunia yang terbatas, mi instan memberi mereka ruang untuk mengekspresikan kreativitas dan memperoleh sedikit kegembiraan.",
      "Pilihan terpidana mati untuk memasak mi instan persis seperti gambar kemasan mencerminkan kemampuan manusia untuk menemukan keindahan dalam kesederhanaan. Bahkan di situasi paling sulit sekalipun, keputusan seperti itu dapat menjadi simbol ketabahan dan kemampuan untuk menemukan kebahagiaan dalam momen-momen terakhir.",
      "Kisah tentang terpidana mati yang memilih memasak mi instan persis seperti gambar kemasan menjadi pelajaran berharga bagi kita semua. Ia mengajarkan kita untuk tidak melupakan kebebasan dalam memilih apa yang membuat kita bahagia, bahkan di saat-saat yang sulit. Kehidupan adalah tentang menghargai setiap momen, termasuk momen-momen kecil seperti menikmati hidangan sederhana seperti mi instan.",
    ],
  },
  {
    id: 2,
    title: "Resep Mie Toprak Solo yang Komplet Isiannya Untuk Buka Puasa",
    src: "https://akcdn.detik.net.id/community/media/visual/2023/03/26/resep-mie-toprak-solo_43.jpeg?w=700&q=90",
    tags: ["Resep", "Mi", "Pasta"],
    author: "Odilia WS",
    data: "Senin, 27 Mar 2023 10:00 WIB",
    timeToRead: 8,
    content: [
      "Solo, 27 Maret 2023 - Di bulan suci Ramadan ini, banyak orang mencari menu sahur dan buka puasa yang istimewa. Salah satu menu yang patut dicoba adalah Mie Toprak Solo. Mie Toprak Solo merupakan hidangan khas dari Solo yang terkenal dengan kelezatannya.",
      "Mie Toprak Solo memiliki ciri khas mie yang digoreng dengan berbagai bumbu rempah yang khas. Selain mie, hidangan ini juga dilengkapi dengan berbagai isiannya yang membuatnya semakin komplet dan menggugah selera.",
      "Isian dari Mie Toprak Solo biasanya terdiri dari daging ayam, suwiran daging sapi, tauge, sayuran, dan telur. Semua bahan ini dikombinasikan dengan sempurna sehingga menghasilkan hidangan yang lezat dan mengenyangkan.",
    ],
  },
  {
    id: 3,
    title: "Resep Mie Ayam Rica yang Gurih Pedasnya Bikin Ketagihan",
    src: "https://akcdn.detik.net.id/community/media/visual/2023/03/04/resep-mie-ayam-rica.jpeg?w=700&q=90",
    tags: ["Resep", "Mi", "Pasta"],
    author: "Odilia WS",
    data: "Minggu, 05 Mar 2023 09:00 WIB",
    timeToRead: 7,
    content: [
      "Jakarta - Sengatan pedas enak mie ayam ini bisa menambah selera makan. Mienya mulur lembut dengan topping ayam tumis yang pedas nendang. Pedas mantap!",
      "Kalau ingin menyantap mie ayam yang lebih nendang, kamu bisa meracik mie ayam rica ini. Memakai bumbu rica atau cabe khas Manado, mie ayam ini rasanya lebih menantang.",

      "Rasa pedasnya berasal dari cabe bubuk, minyak cabe dan saus cabe botolan. Kalau kurang menyengat bisa kamu tambahkan irisan cabe rawit merah atau cabe merah segar.",

      "Yang terpenting, pilih mie ayam telur yang bagus kualitasnya agar rasanya gurih mulur. Bisa kamu sajikan dengan kuah kaldu, pangsit atau bakso. Cocok buat santapan akhir pekan. Resepnya ada di bawah ini.",
    ],
  },
  {
    id: 4,
    title: "Resep Mie Goreng Ayam Bumbu Jepang yang Mulur Gurih Buat Sarapan",
    src: "https://akcdn.detik.net.id/community/media/visual/2023/03/06/resep-mie-goreng-ayam-bumbu-jepang.jpeg?w=700&q=90",
    tags: ["Resep", "Mi", "Pasta"],
    author: "Odilia WS",
    data: "Minggu, 05 Mar 2023 09:00 WIB",
    timeToRead: 4,
    content: [
      "Mie goreng yang mulur gurih ini pasti disukai keluarga. Bisa jadi pilihan enak untuk sarapan atau bekal. Tambahkan telur agar nutrisinya makin lengkap.",
      "Mie goreng Jepang dikenal sebagai yakisoba. Bahan-bahannya sederhana dan tak berbeda jauh dengan mie goreng dari negara lain termasuk Indonesia. Berupa mie segar, ayam atau daging dan sayuran.",
      "Bumbu yang istimewa adalah shoyu atau kecap Jepang dengan rasa gurih umami. Isian lainnya adalah daging ayam, kol dan wortel. Membuat mie goreng ini jadi makin gurih enak.",
    ],
  },
  {
    id: 5,
    title: "Resep Mie Nyemek Udang Sayuran yang Enak Buat Hangatkan Badan",
    src: "https://akcdn.detik.net.id/community/media/visual/2023/02/15/resep-mie-nyemek-udang-sayuran_43.jpeg?w=700&q=90",
    tags: ["Resep", "Mi", "Kuah", "Udang"],
    author: "Pramita",
    data: "Kamis, 16 Feb 2023 11:00 WIB",
    timeToRead: 10,
    content: [
      "Kalau tak ingin makan nasi, mie nyemek dengan isian udang dan sayuran ini bisa jadi pengganti. Mienya mulur gurih dengan kuah kaldu dan telur yang lezat.",
      "Mie atau bakmi yang terbuat dari tepung terigu bisa jadi sumber karbohidrat. Bisa diolah dengan paduan bahan protein dan sayuran yang kaya akan vitamin dan serat.",
    ],
  },
  {
    id: 6,
    title: "5 Cara Membuat Martabak Mie yang Lezat dan Mudah Dicoba di Rumah",
    src: "https://cdn1-production-images-kly.akamaized.net/Ixnxay9xEwZhQps2bIagho-usPU=/640x360/smart/filters:quality(75):strip_icc():format(jpeg)/kly-media-production/medias/3127361/original/081888400_1589382996-Martabak_Mesir.jpg",
    tags: ["Resep", "Martabak", "Mi", "Kornet"],
    author: "Bimo Bagas Basworo",
    data: "Rabu, 20 Jul 2022, 10:50 WIB",
    timeToRead: 11,
    content: [
      "Mie adalah salah satu makanan yang populer di Indonesia dan juga seluruh dunia. Makanan ini digemari oleh begitu banyak orang dari berbagai kalangan. Hampir setiap daerah memiliki olahan mie yang khas sendiri.",
      "Hidangan ini semakin populer sejak ditemukannya mie instan. Harga mie instan yang murah, cara membuatnya yang mudah, serta rasanya yang lezat membuatnya dicintai oleh banyak orang, meskipun beberapa penelitian menyebutkan bahwa konsumsi mie instan tidak baik untuk kesehatan.",
      "Salah satu olahan mie yang populer belakangan ini adalah martabak mie. Cara membuat martabak mie yang mudah dan simpel membuat hidangan ini disukai oleh banyak orang. Beraneka ragam cara untuk membuat martabak mie menambah kepopuleran hidangan ini di masyarakat. Selain itu, hidangan ini juga cukup murah untuk dibuat. Anda juga bisa menggunakan mie instan untuk membuat martabak mie.",
    ],
  },
  {
    id: 7,
    title:
      "Kreasi Sebelum Harga Mi Instan Naik, Gabungkan 2 Merek Berbeda untuk Kombinasi Rasa Sempurna",
    src: "https://cdn0-production-images-kly.akamaized.net/FHl5qOWRJ320za2K48jXSJKVGnA=/640x360/smart/filters:quality(75):strip_icc():format(jpeg)/kly-media-production/medias/3343838/original/051486900_1610093813-20210108-Store-Mie-Instan-dibuat-Instagrammable-TALLO-3.jpg",
    tags: ["Hot", "Produk", "Mi", "Terbaru"],
    author: "Henry",
    data: "Sabtu, 11 Agu 2022, 16:02 WIB",
    timeToRead: 11,
    content: [
      "Menteri Pertanian (Mentan) Syahrul Yasin Limpo sebelumnya mengungkap kenaikan harga itu akan terjadi dalam waktu dekat. Itu sebagai dampak tertahannya 180 juta ton gandum di Ukraina. Belum diketahui dengan pasti apakah kenaikan harga mi instan akan terjadi yang kabarnya sampai tiga kali lipat.",
    ],
  },
  {
    id: 8,
    title:
      "Razhati, Mi Instan Sehat Berbahan Baku Buah dan Sayur ala UMKM Medan",
    src: "https://cdn1-production-images-kly.akamaized.net/Ah_j10a9LzgIqjvsGhjXUlHLlfU=/640x360/smart/filters:quality(75):strip_icc():format(jpeg)/kly-media-production/medias/4428820/original/021463300_1684159969-WhatsApp_Image_2023-05-15_at_20.29.08.jpeg",
    tags: ["UMKM", "Produk", "Mi", "Terbaru"],
    author: "Reza Efendi",
    data: "Senin, 7 Mei 2023, 21:12 WIB",
    timeToRead: 14,
    content: [
      "Mi instan sehat Razhati merupakan salah satu produksi dari pelaku Usaha Mikro Kecil Menengah (UMKM) yang menjadi binaan pihak Kecamatan Medan Kota, Kota Medan.",
    ],
  },
  {
    id: 9,
    title:
      "Pakar Farmasi: Tak Perlu Khawatir soal Etilen Oksida pada Mi Instan, Ini Gas yang Mudah Menguap",
    src: "https://cdn0-production-images-kly.akamaized.net/1ae5ViYqqPQe56b7Rt2KcwxbmRk=/640x360/smart/filters:quality(75):strip_icc():format(jpeg)/kly-media-production/medias/3228916/original/059643200_1599218444-MIINSTANCOV.jpg",
    tags: ["Health", "Mi", "Terbaru"],
    author: "Diviya Agatha",
    data: "Jumat, 5 Mei 2023, 10:10 WIB",
    timeToRead: 16,
    content: [
      "Munculnya temuan zat pemicu kanker berupa etilen oksida (EtO) pada mi instan Malaysia oleh otoritas Taiwan menimbulkan kekhawatiran tersendiri. Bagaimana tidak? Mi instan sudah lama menjadi makanan favorit untuk banyak orang.",
    ],
  },
  {
    id: 10,
    title: "Kurang Apalagi? Muda, Kaya, & Pewaris Kerajaan Mie Instan RI",
    src: "https://akcdn.detik.net.id/visual/2020/12/07/axton-salim-ist_169.png?w=715&q=90",
    tags: ["Tokoh", "Terbaru"],
    author: "Romys Binekasri",
    data: "Kamis, 4 Mei 2023, 10:10 WIB",
    timeToRead: 17,
    content: [
      "Axton salim menjadi pewaris tahta gurita bisnis sang Ayah, Anthony Salim. Melalui perusahan mie instan, melalui PT Indofood Sukses Makmur Tbk (ICBP), Axton ternyata memiliki gurita bisnisnya sendiri.",
    ],
  },
  {
    id: 11,
    title: "Resep Mi Kuah Rumput Laut yang Gurih Menyehatkan",
    src: "https://akcdn.detik.net.id/community/media/visual/2021/10/18/resep-mie-kuah-rumput-laut-1.jpeg?w=700&q=90",
    tags: ["Rumput Laut", "Resep"],
    author: "Andreas",
    data: "Rabu, 3 Mei 2023, 10:00 WIB",
    timeToRead: 17,
    content: [
      "Pengin makan yang gurih hangat? Mie dengan kaldu rumput laut dan sedikit cabe ini bisa hangatkan badan. Kuahnya gurih alami dan enak dihirup hangat.",
      "Rumput laut yang dikeringkan dan dikenal sebagai wakame merupakan bahan utama kaldu atau dashi dalam masakan Jepang dan Korea. Ini karena wakame mengandung mineral dan sejumlah vitamin.",
    ],
  },
];

const dataTestimonial = [
  {
    name: "Rina Fitriani",
    desc: "Saya sudah mencoba berbagai jenis mi di MiTime, semuanya lezat! Pelayanan juga ramah. Terima kasih, MiTime!",
    date: "2 hari yang lalu",
    src: P1,
    star: 5,
  },
  {
    name: "Vivi",
    desc: "MiTime adalah tempat favorit saya untuk makan mi. Rasa mi-nya selalu konsisten dan nikmat. Pasti kembali lagi!",
    date: "9 hari yang lalu",

    src: P2,
    star: 5,
  },
  {
    name: "Yohanes Alvian",
    desc: "Pelayanan ramah, makanan enak dan terjangkau tapi lumayan lama karna ramai. Pastinya akan balik lagi di lain waktu.",
    date: "6 hari yang lalu",
    src: P3,
    star: 4,
  },
  {
    name: "Dewi Anggraeni",
    desc: "Mi di MiTime sangat enak! Rasanya autentik dan bumbunya pas. Recommended!",
    date: "14 hari yang lalu",
    src: P4,
    star: 5,
  },
];
// module.exports = {
//   dataNavbar,
//   dataReview,
//   dataButton,
//   dataMenu,
//   dataQuickLinks,
//   dataSupports,
//   dataFollowUs,
// };

export {
  dataNavbar,
  dataReview,
  dataMengapaKami,
  dataButton,
  dataMenu,
  dataQuickLinks,
  dataSupports,
  dataFollowUs,
  dataBlogs,
  dataTestimonial,
};
