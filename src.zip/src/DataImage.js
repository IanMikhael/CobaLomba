import ImageMudah from "../src/Assets/MengapaKami/Mudah.svg";
import ImageMurah from "../src/Assets/MengapaKami/Murah.svg";
import ImageCepat from "../src/Assets/MengapaKami/Cepat.svg";

module.exports = { ImageMudah, ImageMurah, ImageCepat };
