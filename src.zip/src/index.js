import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App";
import Store from "./Pages/Store";
import Reservasi from "./Pages/Reservasi";
import Payment from "./Pages/Payment";
import Blogs from "./Pages/Blogs";
import BlogDetail from "./Components/Blogs/BlogDetail";
import { createBrowserRouter, RouterProvider } from "react-router-dom";

const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
  },
  {
    path: "store",
    element: <Store />,
  },
  {
    path: "reserve",
    element: <Reservasi />,
  },
  {
    path: "store/payment",
    element: <Payment />,
  },
  {
    path: "blogs",
    element: <Blogs />,
  },
  {
    path: "blogs/details",
    element: <BlogDetail />,
  },
]);

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  // <React.StrictMode>
  <RouterProvider router={router} />
  // </React.StrictMode>
);
