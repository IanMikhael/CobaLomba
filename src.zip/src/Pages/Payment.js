import React from "react";
import Navbar from "../Components/Navbar/Navbar";
import Invoice from "../Components/Payment/Invoice";
import FoodDelivery from "../Components/Payment/FoodDelivery";
import Notes from "../Components/Payment/Notes";
import Method from "../Components/Payment/Method";
import PaymentButton from "../Components/Payment/PaymentButton";
import Footer from "../Components/Footer/Footer";
import { useLocation } from "react-router-dom";

import ScrollToTop from "../Components/UI/ScrollToTop";

export default function Payment() {
  const location = useLocation();

  // Deserialize the data from the URL parameter
  const searchParams = new URLSearchParams(location.search);
  const dataString = searchParams.get("data");
  const data = JSON.parse(decodeURIComponent(dataString));
  console.log(data);
  return (
    <div className="flex flex-col gap-8 border bg-primary">
      <ScrollToTop />
      <section className="relative w-full h-20">
        <Navbar />
      </section>
      <main className="flex flex-col gap-4 md:flex-row containers">
        <section className="flex flex-col gap-4 md:w-2/3">
          <Invoice data={data} />
          <Notes />
        </section>
        <section className="flex flex-col w-full gap-4 md:w-1/3">
          <FoodDelivery />
          <Method />
          <PaymentButton total={data.totalPrice} />
        </section>
      </main>
      <Footer />
    </div>
  );
}
