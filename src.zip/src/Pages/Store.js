import React, { useState } from "react";
import Navbar from "../Components/Navbar/Navbar";
import StoreList from "../Components/Store/StoreList";
import PopupCart from "../Components/Store/PopupCart";
import ScrollToTop from "../Components/UI/ScrollToTop";
import Footer from "../Components/Footer/Footer";

export default function Store() {
  const [data, setData] = useState([0]);
  const [showAlert, setShowAlert] = useState(false);
  const [totalPrice, setTotalPrice] = useState();

  const dataHandler = (data) => {
    setData(data);
  };

  const priceHandler = (price) => {
    setTotalPrice(price);
  };

  const cartHandler = () => {
    setShowAlert((prevShowAlert) => !prevShowAlert);
  };

  return (
    <div className="relative flex flex-col gap-8 bg-primary">
      <ScrollToTop />
      <section className="relative w-full h-20">
        <Navbar q={data.length} cartOnClick={cartHandler} onShow={showAlert} />
      </section>
      <StoreList updateData={dataHandler} updatePrice={priceHandler} />

      {/* Show popup cart when clicked */}

      {showAlert ? (
        <PopupCart
          data={data}
          totalPrice={totalPrice}
          cartOnClick={cartHandler}
        />
      ) : null}

      <Footer />
    </div>
  );
}
