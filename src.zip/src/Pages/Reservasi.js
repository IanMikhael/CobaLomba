import React, { useState } from "react";
import Navbar from "../Components/Navbar/Navbar";
import ReservasiForm from "../Components/Reservasi/ReservasiForm";
import Footer from "../Components/Footer/Footer";
import Alert from "../Components/UI/Alert";
import ScrollToTop from "../Components/UI/ScrollToTop";

export default function Reservasi() {
  const [showAlert, setShowAlert] = useState(false);

  const handleButtonClick = () => {
    setShowAlert(true);
  };

  const handleCloseAlert = () => {
    setShowAlert(false);
  };

  return (
    <div className="relative flex flex-col gap-8 border bg-primary">
      <ScrollToTop />
      <section className="relative w-full h-20">
        <Navbar />
      </section>
      <div className="flex flex-col gap-8 containers">
        <ReservasiForm showAlertHandler={handleButtonClick} />

        {showAlert ? (
          <Alert
            message={{
              title: "Reservasi Berhasil!",
              content:
                "Informasi mengenai reservasi anda akan dikirimkan melalui email.",
              additional: {
                text: "Mengalami kendala dalam reservasi? Hubungi",
                link: "0812-1234-1243",
              },
            }}
            onClose={handleCloseAlert}
          />
        ) : null}
      </div>

      <Footer />
    </div>
  );
}
