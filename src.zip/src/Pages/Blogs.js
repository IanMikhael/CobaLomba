import React from "react";
import Navbar from "../Components/Navbar/Navbar";
import BlogsPage from "../Components/Blogs/BlogsPage";
import BlogsContent from "../Components/Blogs/BlogsContent";
import Footer from "../Components/Footer/Footer";
import ScrollToTop from "../Components/UI/ScrollToTop";

export default function Blogs() {
  return (
    <div className="bg-primary">
      <ScrollToTop />
      <section className="relative w-full h-20 mb-8">
        <Navbar />
      </section>
      <div className="flex flex-col gap-8 mb-16">
        <BlogsPage />
        <BlogsContent />
      </div>
      <Footer />
    </div>
  );
}
